package cn.videostudy.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.type.TypeReference;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.dao.DuplicateKeyException;
import java.util.*;

@Repository
public class PracticeStore {
    private static final org.slf4j.Logger log=org.slf4j.LoggerFactory.getLogger(PracticeStore.class);
    private final JdbcTemplate jdbc;
    private final ObjectMapper json;
    private final TransactionTemplate tx;
    public record SetJob(String id,String analysisId,String sourceHash,String title,String status,
                         Map<String,Object> source,Map<String,Object> result,String error) {}
    public record Run(String id,String token,Map<String,Object> source) {}
    public PracticeStore(JdbcTemplate jdbc,ObjectMapper json) {
        this.jdbc=jdbc;this.json=json;
        tx=new TransactionTemplate(new DataSourceTransactionManager(Objects.requireNonNull(jdbc.getDataSource())));
    }
    private String encode(Object data) {
        try{return json.writeValueAsString(data);}catch(Exception error){throw new IllegalStateException(error);}
    }
    private Map<String,Object> decode(String data) {
        if(data==null)return null;
        try{return json.readValue(data,new TypeReference<Map<String,Object>>(){});}catch(Exception error){throw new IllegalStateException(error);}
    }
    public SetJob request(String analysis,String hash,String key,String title,Map<String,Object> source,boolean retry) {
        try{jdbc.update("INSERT INTO practice_sets(id,transcription_id,source_hash,request_key,scope_title,status,source_json) VALUES (?,?,?,?,?,'queued',?)",
            UUID.randomUUID().toString(),analysis,hash,key,title,encode(source));}
        catch(org.springframework.dao.DataAccessException existing){if(!DatabaseDialect.duplicate(existing))throw existing;/* Same evidence and settings reuse a saved set. */}
        if(retry){
            long retryStarted=System.nanoTime();String retryRequest=UUID.randomUUID().toString();
            int failedReset=jdbc.update("UPDATE practice_sets SET status='queued',attempt_count=0,result_json=NULL,error_code=NULL,run_token=NULL WHERE transcription_id=? AND request_key=? AND status='failed'",analysis,key);
            if(failedReset>0)log.info("Practice task={} request={} stage=explicit_retry result=queued previous=failed elapsed_ms={}",analysis,retryRequest,(System.nanoTime()-retryStarted)/1000000);
            // Compare the exact completed result so concurrent retry requests cannot reset an active run.
            var completed=jdbc.query("SELECT id,result_json FROM practice_sets WHERE transcription_id=? AND request_key=? AND status='completed'",(r,n)->new String[]{r.getString(1),r.getString(2)},analysis,key);
            for(var row:completed){var result=decode(row[1]);Object questions=result==null?null:result.get("questions");
                if(questions==null||(questions instanceof List<?> list&&list.isEmpty())){
                    String condition=row[1]==null?"result_json IS NULL":"result_json=?";
                    var args=new ArrayList<Object>();args.add(row[0]);if(row[1]!=null)args.add(row[1]);
                    int changed=jdbc.update("UPDATE practice_sets SET status='queued',attempt_count=0,result_json=NULL,error_code=NULL,run_token=NULL WHERE id=? AND status='completed' AND "+condition,args.toArray());
                    if(changed>0)log.info("Practice task={} course={} request={} stage=explicit_retry result=queued previous=empty_completed elapsed_ms={}",row[0],analysis,retryRequest,(System.nanoTime()-retryStarted)/1000000);
                }
            }
        }
        String id=jdbc.queryForObject("SELECT id FROM practice_sets WHERE transcription_id=? AND request_key=?",String.class,analysis,key);
        return find(id).orElseThrow();
    }
    public Optional<SetJob> find(String id) {
        return jdbc.query("SELECT * FROM practice_sets WHERE id=?",(r,n)->new SetJob(r.getString("id"),r.getString("transcription_id"),
            r.getString("source_hash"),r.getString("scope_title"),r.getString("status"),decode(r.getString("source_json")),
            decode(r.getString("result_json")),r.getString("error_code")),id).stream().findFirst();
    }
    public int conversationRevision(String analysis,String hash) {
        return jdbc.queryForObject("SELECT COUNT(*) FROM practice_sets WHERE transcription_id=? AND source_hash=? AND status='completed'",Integer.class,analysis,hash);
    }
    public List<Map<String,Object>> generationHistory(String currentId) {
        var current=find(currentId).orElseThrow();
        var history=jdbc.query("SELECT id,scope_title,source_json,result_json FROM practice_sets WHERE transcription_id=? AND source_hash=? AND status='completed' AND id<>? ORDER BY created_at DESC,id DESC LIMIT 50",(r,n)->{
            var source=decode(r.getString("source_json"));var result=decode(r.getString("result_json"));
            var request=new LinkedHashMap<String,Object>();request.put("scopeTitle",r.getString("scope_title"));
            for(String key:List.of("count","difficulty","mode"))if(source!=null&&source.containsKey(key))request.put(key,source.get(key));
            var row=new LinkedHashMap<String,Object>();row.put("id",r.getString("id"));row.put("request",request);
            row.put("questions",result==null?List.of():result.getOrDefault("questions",List.of()));return (Map<String,Object>)row;
        },current.analysisId(),current.sourceHash(),currentId);
        Collections.reverse(history);return history;
    }
    public List<String> due(){return jdbc.query("SELECT id FROM practice_sets WHERE status='queued' AND attempt_count<2 ORDER BY created_at LIMIT 5",(r,n)->r.getString(1));}
    public Optional<Run> claim(String id) {
        String token=UUID.randomUUID().toString();
        if(jdbc.update("UPDATE practice_sets SET status='processing',attempt_count=attempt_count+1,run_token=? WHERE id=? AND status='queued' AND attempt_count<2",token,id)!=1)return Optional.empty();
        return find(id).map(set->new Run(id,token,set.source()));
    }
    public void complete(Run run,Map<String,Object> result) {
        jdbc.update("UPDATE practice_sets SET status='completed',result_json=?,error_code=NULL,run_token=NULL WHERE id=? AND run_token=? AND status='processing'",encode(result),run.id(),run.token());
    }
    public void fail(Run run,String code,boolean temporary) {
        jdbc.update("UPDATE practice_sets SET status=CASE WHEN ? AND attempt_count<2 THEN 'queued' ELSE 'failed' END,error_code=?,run_token=NULL WHERE id=? AND run_token=?",temporary,code,run.id(),run.token());
    }
    public void recover(){jdbc.update("UPDATE practice_sets SET status=CASE WHEN attempt_count<2 THEN 'queued' ELSE 'failed' END,run_token=NULL,error_code='practice_interrupted' WHERE status='processing'");}
    private SetJob owned(String analysis,String id) {
        var set=find(id).orElseThrow(()->new IllegalArgumentException("practice_not_found"));
        if(!set.analysisId().equals(analysis))throw new IllegalArgumentException("practice_not_found");
        return set;
    }
    @SuppressWarnings("unchecked") private List<Map<String,Object>> questions(SetJob set) {
        return set.result()==null?List.of():(List<Map<String,Object>>)set.result().getOrDefault("questions",List.of());
    }
    public Map<String,Object> publicSet(String analysis,String id) {
        var set=owned(analysis,id);var result=new LinkedHashMap<String,Object>();
        result.put("id",id);result.put("analysisId",analysis);result.put("sourceHash",set.sourceHash());result.put("title",set.title());
        result.put("status",set.status());result.put("error",set.error());
        result.put("count",set.source().get("count"));result.put("difficulty",set.source().get("difficulty"));
        result.put("practiceMode",set.source().getOrDefault("mode","legacy"));
        if(set.result()!=null)for(String key:List.of("rejectedCount","requestedCount","generatedCount","shortfallCount","fillAttempts","fillStatus","modelId","promptVersion","historyRounds","historyQuestions","historySummarized"))result.put(key,set.result().get(key));
        result.put("questions",questions(set).stream().map(q->{
            var publicQuestion=new LinkedHashMap<String,Object>();
            for(String key:List.of("id","nodeId","nodeTitle","kind","title","prompt","options","diagram","scenario","validation"))
                if(q.containsKey(key))publicQuestion.put(key,q.get(key));
            return publicQuestion;
        }).toList());
        return result;
    }
    public List<Map<String,Object>> list(String analysis) {
        return jdbc.query("SELECT id FROM practice_sets WHERE transcription_id=? ORDER BY created_at DESC",(r,n)->r.getString(1),analysis)
            .stream().map(id->{var set=publicSet(analysis,id);set.remove("questions");return set;}).toList();
    }
    public String createSession(String analysis,String setId,String client) {
        var set=owned(analysis,setId);
        if(!"completed".equals(set.status())||questions(set).isEmpty())throw new IllegalArgumentException("practice_not_ready");
        String id=UUID.randomUUID().toString();
        jdbc.update("INSERT INTO practice_sessions(id,set_id,client_id) VALUES (?,?,?)",id,setId,client);return id;
    }
    public Optional<String> latestSession(String set,String client){return jdbc.query("SELECT id FROM practice_sessions WHERE set_id=? AND client_id=? ORDER BY created_at DESC LIMIT 1",(r,n)->r.getString(1),set,client).stream().findFirst();}
    private void requireSession(String analysis,String set,String session,String client) {
        owned(analysis,set);
        if(jdbc.queryForObject("SELECT COUNT(*) FROM practice_sessions WHERE id=? AND set_id=? AND client_id=?",Integer.class,session,set,client)!=1)
            throw new IllegalArgumentException("practice_session_not_found");
    }
    private Map<String,Object> feedback(Map<String,Object> q,int chosen) {
        int answer=((Number)q.get("answerIndex")).intValue();
        var f=new LinkedHashMap<String,Object>();f.put("questionId",q.get("id"));f.put("selectedIndex",chosen);f.put("answerIndex",answer);
        f.put("correct",chosen==answer);f.put("explanation",q.get("explanation"));f.put("takeaway",q.get("takeaway"));
        f.put("citations",q.getOrDefault("citations",List.of()));
        f.put("selectedReason",chosen==answer?"":((List<?>)q.get("distractorReasons")).get(chosen));return f;
    }
    public Map<String,Object> answer(String analysis,String setId,String session,String client,String questionId,int chosen) {
        return tx.execute(status->{
            requireSession(analysis,setId,session,client);
            var q=questions(owned(analysis,setId)).stream().filter(item->questionId.equals(item.get("id"))).findFirst()
                .orElseThrow(()->new IllegalArgumentException("question_not_found"));
            if(chosen<0||chosen>=((List<?>)q.get("options")).size())throw new IllegalArgumentException("invalid_option");
            try{jdbc.update("INSERT INTO practice_answers(session_id,question_id,selected_index,correct) VALUES (?,?,?,?)",session,questionId,chosen,chosen==((Number)q.get("answerIndex")).intValue());}
            catch(org.springframework.dao.DataAccessException existing){if(!DatabaseDialect.duplicate(existing))throw existing;/* First answer wins, including concurrent requests. */}
            int recorded=jdbc.queryForObject("SELECT selected_index FROM practice_answers WHERE session_id=? AND question_id=?",Integer.class,session,questionId);
            return feedback(q,recorded);
        });
    }
    public void requireChatSession(String analysis,String set,String session,String client,String questionId) {
        requireSession(analysis,set,session,client);
        if(questions(owned(analysis,set)).stream().noneMatch(q->questionId.equals(q.get("id"))))
            throw new IllegalArgumentException("question_not_found");
    }
    @SuppressWarnings("unchecked") public Map<String,Object> chatContext(String analysis,String set,String session,String client,String questionId) {
        requireChatSession(analysis,set,session,client,questionId);
        var job=owned(analysis,set);
        var q=questions(job).stream().filter(item->questionId.equals(item.get("id"))).findFirst().orElseThrow();
        var answers=jdbc.query("SELECT selected_index FROM practice_answers WHERE session_id=? AND question_id=?",(r,n)->r.getInt(1),session,questionId);
        if(answers.isEmpty())throw new IllegalArgumentException("answer_required");
        var evidence=new LinkedHashMap<String,Object>();
        for(var node:(List<Map<String,Object>>)job.source().getOrDefault("nodes",List.of())) {
            if(!Objects.equals(q.get("nodeId"),node.get("id")))continue;
            for(var ref:(List<Map<String,Object>>)node.getOrDefault("evidenceRefs",List.of()))evidence.put((String)ref.get("sourceId"),ref);
        }
        var context=new LinkedHashMap<String,Object>();
        context.put("question",q);context.put("feedback",feedback(q,answers.getFirst()));
        context.put("evidence",new ArrayList<>(evidence.values()));
        var refs=new ArrayList<Map<String,Object>>();evidence.values().forEach(ref->refs.add((Map<String,Object>)ref));
        String text=Objects.toString(q.get("prompt"),"")+Objects.toString(q.get("nodeTitle"),"")+refs.stream().map(ref->Objects.toString(ref.get("quote"),"")).reduce("",String::concat);
        var terms=new HashSet<String>();String normalized=text.toLowerCase().replaceAll("[^\\p{L}\\p{N}]","");
        for(int i=0;i<normalized.length()-1;i++)terms.add(normalized.substring(i,i+2));
        var pages=(List<Map<String,Object>>)job.source().getOrDefault("pages",List.of());
        context.put("pages",pages.stream().filter(page->{
            if(page.get("firstFrameTimeMs") instanceof Number first && page.get("lastFrameTimeMs") instanceof Number last)
                return refs.stream().anyMatch(ref->((Number)ref.get("startMs")).longValue()<=last.longValue()&&((Number)ref.get("endMs")).longValue()>=first.longValue());
            String content=(Objects.toString(page.get("title"),"")+Objects.toString(page.get("content"),"")+Objects.toString(page.get("ocr"),"")).toLowerCase().replaceAll("[^\\p{L}\\p{N}]","");
            return terms.stream().anyMatch(content::contains);
        }).limit(6).toList());
        context.put("courseId",analysis);
        var teaching=(Map<String,Object>)((List<Map<String,Object>>)job.source().getOrDefault("nodes",List.of())).stream()
            .filter(node->Objects.equals(q.get("nodeId"),node.get("id"))).findFirst().orElse(Map.of());
        var map=(Map<String,Object>)job.source().getOrDefault("mindMap",Map.of());
        var richer=findTeachingNode((Map<String,Object>)map.get("root"),Objects.toString(q.get("nodeId"),""));
        context.put("knowledgeNode",richer==null?teaching:richer);
        var selectedPages=(List<Map<String,Object>>)context.get("pages");
        var imageTimes=new LinkedHashSet<Long>();
        for(var ref:refs)if("image".equals(ref.get("sourceType"))&&ref.get("startMs") instanceof Number time)imageTimes.add(time.longValue());
        for(var page:(List<Map<String,Object>>)job.source().getOrDefault("pageGroups",List.of()))
            if(selectedPages.stream().anyMatch(selected->Objects.equals(selected.get("pageIndex"),page.get("pageIndex"))))
                for(var time:(List<Number>)page.getOrDefault("representativeFrameTimesMs",List.of()))imageTimes.add(time.longValue());
        context.put("_imageCandidates",new ArrayList<>(imageTimes));
        if(job.source().get("ignoredRegion")!=null)context.put("_ignoredRegion",job.source().get("ignoredRegion"));
        if(!map.isEmpty())context.put("_mapResult",map);
        var speech=(List<Map<String,Object>>)job.source().getOrDefault("sourceSegments",List.of());
        context.put("courseSpeech",speech.stream().filter(segment->segment.get("startMs") instanceof Number start&&segment.get("endMs") instanceof Number end&&
            (refs.stream().anyMatch(ref->Objects.equals(ref.get("sourceId"),segment.get("id")))||selectedPages.stream().anyMatch(page->page.get("firstFrameTimeMs") instanceof Number first&&page.get("lastFrameTimeMs") instanceof Number last&&start.longValue()<=last.longValue()&&end.longValue()>=first.longValue()))).limit(120).toList());
        var sourceIds=evidence.keySet();
        context.put("referenceExamples",teachingList(map,"examples").stream()
            .filter(example->teachingRefs(example).stream().anyMatch(ref->sourceIds.contains(ref.get("sourceId")))).limit(4).toList());
        return context;
    }
    @SuppressWarnings("unchecked") private static List<Map<String,Object>> teachingList(Map<String,Object> node,String key){
        return node!=null&&node.get(key) instanceof List<?> values?(List<Map<String,Object>>)values:List.of();
    }
    @SuppressWarnings("unchecked") private static Map<String,Object> findTeachingNode(Map<String,Object> node,String id){
        if(node==null)return null;if(Objects.equals(node.get("id"),id))return node;
        for(String key:List.of("children","details"))for(var child:teachingList(node,key)){var found=findTeachingNode(child,id);if(found!=null)return found;}
        return null;
    }
    @SuppressWarnings("unchecked") private static List<Map<String,Object>> teachingRefs(Map<String,Object> node){
        var refs=new ArrayList<>(teachingList(node,"evidenceRefs"));
        for(String key:List.of("children","details"))for(var child:teachingList(node,key))refs.addAll(teachingRefs(child));
        return refs;
    }
    public Map<String,Object> session(String analysis,String setId,String session,String client) {
        requireSession(analysis,setId,session,client);
        var set=owned(analysis,setId);var byId=new HashMap<String,Map<String,Object>>();questions(set).forEach(q->byId.put((String)q.get("id"),q));
        var answers=jdbc.query("SELECT question_id,selected_index FROM practice_answers WHERE session_id=? ORDER BY created_at",(r,n)->feedback(byId.get(r.getString(1)),r.getInt(2)),session);
        return Map.of("id",session,"setId",setId,"feedback",answers);
    }
}
