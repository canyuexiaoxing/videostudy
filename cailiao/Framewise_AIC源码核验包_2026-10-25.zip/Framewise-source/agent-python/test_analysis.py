import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from uuid import uuid4

from analysis import analyze_file


class AnalysisTest(unittest.TestCase):
    def test_optional_subtitle_source_is_published_after_page_understanding(self):
        with tempfile.TemporaryDirectory() as d:
            fid = str(uuid4())
            (Path(d) / fid).write_bytes(b'media')
            page = {'pageIndex': 1, 'imageAnalysis': {'status': 'completed', 'content': 'understood'}}
            with patch.dict(os.environ, {'MEDIA_TEMP_DIR': d, 'KEYFRAME_DIR': str(Path(d)/'frames')}), \
                 patch('analysis.transcribe_file', return_value={'language': 'zh', 'segments': []}), \
                 patch('analysis.VisualOcrWorker') as worker, \
                 patch('analysis.media_duration_ms', return_value=1000), \
                 patch('analysis.review_visual_coverage', return_value=([], {'status': 'completed'})), \
                 patch('analysis.group_pages', return_value=([{'pageIndex': 1}], [])), \
                 patch('analysis.analyze_page', return_value=page), \
                 patch('analysis.publish_subtitle_source') as publish, \
                 patch('analysis.safe_overview', return_value={'status': 'empty'}), \
                 patch('analysis.build_mind_map', return_value={'status': 'empty'}):
                worker.return_value.__enter__.return_value.analyze.return_value = []
                analyze_file(fid, subtitle_callback_token='private-token')
                self.assertEqual(publish.call_args.args[4], [page])
                publish.reset_mock()
                analyze_file(fid)
                publish.assert_not_called()

    def test_main_analysis_finishes_without_starting_overview(self):
        import threading
        started=threading.Event()
        with tempfile.TemporaryDirectory() as d:
            fid=str(uuid4());(Path(d)/fid).write_bytes(b'media')
            speech=[{'id':'s1','startMs':0,'endMs':1000,'text':'讲解'}]
            page={'pageIndex':1,'imageAnalysis':{'status':'completed','content':'完整页面理解'}}
            def overview(segments,pages):
                self.assertEqual(pages[0]['imageAnalysis']['content'],'完整页面理解')
                started.set();return {'status':'completed'}
            def mind_map(*args,**kwargs):
                self.assertFalse(started.is_set(),'Overview is a separate post-map job')
                return {'status':'completed'}
            with patch.dict(os.environ,{'MEDIA_TEMP_DIR':d,'KEYFRAME_DIR':str(Path(d)/'frames')}), \
                 patch('analysis.transcribe_file',return_value={'language':'zh','segments':speech}), \
                 patch('analysis.VisualOcrWorker') as worker, \
                 patch('analysis.media_duration_ms',return_value=1000), \
                 patch('analysis.review_visual_coverage',return_value=([],{'status':'completed'})), \
                 patch('analysis.group_pages',return_value=([{'pageIndex':1}],[])), \
                 patch('analysis.analyze_page',return_value=page), \
                 patch('analysis.safe_overview',side_effect=overview), \
                 patch('analysis.build_mind_map',side_effect=mind_map):
                worker.return_value.__enter__.return_value.analyze.return_value=[]
                result=analyze_file(fid)
            self.assertIsNone(result['overview'])
            self.assertNotIn('overview',result['stageTimingsMs'])

    def test_later_failure_reuses_completed_media_stages_on_retry(self):
        with tempfile.TemporaryDirectory() as d:
            fid = str(uuid4())
            (Path(d) / fid).write_bytes(b'media')
            with patch.dict(os.environ, {'MEDIA_TEMP_DIR': d, 'KEYFRAME_DIR': str(Path(d) / 'frames')}), \
                 patch('analysis.transcribe_file', return_value={'language':'zh','segments':[]}) as speech, \
                 patch('analysis.VisualOcrWorker') as worker, \
                 patch('analysis.media_duration_ms', return_value=3000), \
                 patch('analysis.review_visual_coverage', return_value=([], {'status':'completed'})) as review, \
                 patch('analysis.group_pages', side_effect=[RuntimeError('later failure'), ([], [])]) as group, \
                 patch('analysis.build_mind_map', return_value={'status':'empty'}):
                worker.return_value.__enter__.return_value.analyze.return_value = []
                with self.assertRaises(RuntimeError): analyze_file(fid)
                result = analyze_file(fid)
                self.assertEqual(speech.call_count, 1)
                self.assertEqual(worker.return_value.__enter__.return_value.analyze.call_count, 1)
                self.assertEqual(review.call_count, 1)
                self.assertEqual(group.call_count, 2)
                self.assertEqual(result['reusedCheckpoints'], {'transcription':1, 'visualOcr':1, 'coverageReview':1})

    def test_analysis_persists_grounded_mind_map_after_page_understanding(self):
        with tempfile.TemporaryDirectory() as directory:
            file_id = str(uuid4())
            (Path(directory) / file_id).write_bytes(b"fake media")
            speech = [{"id": "t_1", "startMs": 1000, "endMs": 1900, "text": "增长量等于现期减基期"}]
            expected = {"status": "completed", "root": {"title": "课程知识导图", "children": []}}
            with patch.dict(os.environ, {"MEDIA_TEMP_DIR": directory, "KEYFRAME_DIR": str(Path(directory) / "keyframes")}), \
                 patch("analysis.transcribe_file", return_value={"language": "zh", "segments": speech}), \
                 patch("analysis.VisualOcrWorker") as worker, \
                 patch("analysis.media_duration_ms", return_value=3000), \
                 patch("analysis.review_visual_coverage", return_value=([], {"status": "not_applicable"})), \
                 patch("analysis.group_pages", return_value=([], [])), \
                 patch("analysis.build_mind_map", return_value=expected) as build:
                worker.return_value.__enter__.return_value.analyze.return_value = []
                result = analyze_file(file_id)
            self.assertEqual(build.call_args.args, (speech, []))
            self.assertIn('checkpoint', build.call_args.kwargs)
            self.assertEqual(result["mindMap"], expected)

    def test_ocr_only_keeps_page_groups_without_sending_images(self):
        with tempfile.TemporaryDirectory() as directory:
            file_id = str(uuid4())
            (Path(directory) / file_id).write_bytes(b"fake media")
            page = {"pageIndex": 1, "firstFrameTimeMs": 1000, "lastFrameTimeMs": 2000,
                    "memberFrameTimesMs": [1000, 2000], "representativeFrameTimesMs": [2000],
                    "ocrLines": [], "imageAnalysis": None}
            visuals = [{"frameTimeMs": time, "ocrBlocks": []} for time in (1000, 2000)]
            with patch.dict(os.environ, {"MEDIA_TEMP_DIR": directory, "KEYFRAME_DIR": str(Path(directory) / "keyframes")}), \
                 patch("analysis.transcribe_file", return_value={"language": "zh", "segments": []}), \
                 patch("analysis.VisualOcrWorker") as worker, \
                 patch("analysis.media_duration_ms", return_value=3000), \
                 patch("analysis.review_visual_coverage", return_value=(visuals, {"status": "completed"})), \
                 patch("analysis.group_pages", return_value=([page], [])), \
                 patch("analysis.analyze_page", side_effect=lambda page, pages, frames, root, segments, mode:
                       {**page, "textAnalysis": {"status": "completed", "title": "OCR page", "content": "speech+OCR",
                                                  "visualElements": [], "uncertainties": []}}) as analyze:
                worker.return_value.__enter__.return_value.analyze.return_value = visuals
                result = analyze_file(file_id, "ocr_only")
            analyze.assert_called_once()
            self.assertEqual(analyze.call_args.args[-1], "ocr_only")
            self.assertEqual(result["pageGroups"][0]["memberFrameTimesMs"], [1000, 2000])
            self.assertEqual(result["pageGroups"][0]["textAnalysis"]["title"], "OCR page")
            self.assertIsNone(result["imageModelId"])
            self.assertEqual(result["visualAnalysisMode"], "ocr_only")
            worker.assert_called_once()
            self.assertEqual(worker.call_args.kwargs["page_change_fraction"], 0.03)

    def test_selected_threshold_reaches_visual_worker(self):
        for threshold in (0.5, 1, 2, 3, 4, 5):
            with tempfile.TemporaryDirectory() as directory:
                file_id = str(uuid4())
                (Path(directory) / file_id).write_bytes(b"fake media")
                with patch.dict(os.environ, {"MEDIA_TEMP_DIR": directory, "KEYFRAME_DIR": str(Path(directory) / "keyframes")}), \
                     patch("analysis.transcribe_file", return_value={"language": "zh", "segments": []}), \
                     patch("analysis.VisualOcrWorker") as worker, \
                     patch("analysis.media_duration_ms", return_value=3000), \
                     patch("analysis.review_visual_coverage", return_value=([], {"status": "not_applicable"})), \
                     patch("analysis.group_pages", return_value=([], [])):
                    worker.return_value.__enter__.return_value.analyze.return_value = []
                    result = analyze_file(file_id, coarse_change_percent=threshold)
                self.assertEqual(worker.call_args.kwargs["page_change_fraction"], threshold / 100)
                self.assertEqual(result["coarseChangePercent"], threshold)

    def test_both_sends_only_page_representatives(self):
        with tempfile.TemporaryDirectory() as directory:
            file_id = str(uuid4())
            (Path(directory) / file_id).write_bytes(b"fake media")
            visuals = [{"frameTimeMs": time, "ocrBlocks": []} for time in (1000, 2000, 3000)]
            page = {"pageIndex": 1, "firstFrameTimeMs": 1000, "lastFrameTimeMs": 3000,
                    "memberFrameTimesMs": [1000, 2000, 3000], "representativeFrameTimesMs": [3000],
                    "ocrLines": [], "imageAnalysis": None}
            sent = []
            def fake_analyze(page, pages, frames, root, segments, mode):
                sent.append((page["representativeFrameTimesMs"], mode, segments))
                return {**page, "imageAnalysis": {"status": "completed", "title": "Final", "content": "visible",
                                                 "visualElements": [], "uncertainties": []}}
            with patch.dict(os.environ, {"MEDIA_TEMP_DIR": directory, "KEYFRAME_DIR": str(Path(directory) / "keyframes")}), \
                 patch("analysis.transcribe_file", return_value={"language": "zh", "segments": []}), \
                 patch("analysis.VisualOcrWorker") as worker, \
                 patch("analysis.media_duration_ms", return_value=4000), \
                 patch("analysis.review_visual_coverage", return_value=(visuals, {"status": "completed"})), \
                 patch("analysis.group_pages", return_value=([page], [])), \
                 patch("analysis.analyze_page", side_effect=fake_analyze):
                worker.return_value.__enter__.return_value.analyze.return_value = visuals
                result = analyze_file(file_id)
            self.assertEqual(sent, [([3000], "both", [])])
            self.assertEqual(result["pageGroups"][0]["imageAnalysis"]["title"], "Final")
            self.assertEqual(len(result["visualEvidence"]), 3)

    def test_video_remains_available_through_agent_review(self):
        with tempfile.TemporaryDirectory() as directory:
            file_id = str(uuid4())
            path = Path(directory) / file_id
            path.write_bytes(b"fake media")
            with patch.dict(os.environ, {"MEDIA_TEMP_DIR": directory, "KEYFRAME_DIR": str(Path(directory) / "keyframes")}):
                with patch("analysis.transcribe_file", return_value={"language": "zh", "segments": []}), \
                     patch("analysis.VisualOcrWorker") as worker, \
                     patch("analysis.media_duration_ms", return_value=3000), \
                     patch("analysis.group_pages", return_value=([{"pageIndex": 1, "firstFrameTimeMs": 1000,
                         "lastFrameTimeMs": 1000, "memberFrameTimesMs": [1000],
                         "representativeFrameTimesMs": [1000], "ocrLines": [], "imageAnalysis": None}], [])), \
                     patch("analysis.analyze_page", side_effect=lambda page, pages, frames, root, segments, mode:
                           {**page, "imageAnalysis": {"status": "completed", "title": "Slide", "content": "Text",
                                                      "visualElements": [], "uncertainties": []}}), \
                     patch("analysis.review_visual_coverage", return_value=(
                         [{"frameTimeMs": 1000, "ocrBlocks": []}],
                         {"status": "completed", "resampledTimesMs": [], "concerns": []},
                     )) as review:
                    worker.return_value.__enter__.return_value.analyze.return_value = [{"frameTimeMs": 1000, "ocrBlocks": []}]
                    result = analyze_file(file_id)

            self.assertTrue(path.exists())
            self.assertEqual(result["review"]["status"], "completed")
            self.assertEqual(result["imageModelId"], "deepseek-flash")
            self.assertEqual(result["pageGroups"][0]["imageAnalysis"]["title"], "Slide")
            review.assert_called_once()


if __name__ == "__main__":
    unittest.main()
