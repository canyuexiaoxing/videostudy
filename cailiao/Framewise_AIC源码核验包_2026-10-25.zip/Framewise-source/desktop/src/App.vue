<script setup lang="ts">
import {waitForRuntimeReady,readCourseJson,readDelay} from './courseReadRecovery'
import { unavailableAnalysisModules } from './nativeRuntime'
import { API_ORIGIN, setApiOrigin } from './apiOrigin' 
import { computed, nextTick, onMounted, onUnmounted, ref, watch } from 'vue'
import MindMapCanvas from './MindMapCanvas.vue'
import MindMapDialog from './MindMapDialog.vue'
import MindMapEvidenceDetails from './MindMapEvidenceDetails.vue'
import StudyIcon from './StudyIcon.vue'
import WorkspaceDivider from './WorkspaceDivider.vue'
import StudyNotes from './StudyNotes.vue'
import ChapterPlayer from './ChapterPlayer.vue'
import AnalysisProgressBar from './AnalysisProgress.vue'
import type { AnalysisProgress } from './analysisProgress'
import VideoWorkspace from './VideoWorkspace.vue'
import {loadPersonSelection,savePersonSelection} from './personSelection'
import type {PersonSelectionMode} from './personSelection'
import { normalizeIgnoreSetting } from './videoRegionTimeline'
import type { IgnoreSetting } from './videoRegionTimeline'
import SubtitleSettings from './SubtitleSettings.vue'
import AiOverview from './AiOverview.vue'
import OverviewChat from './OverviewChat.vue'
import CloudSyncDialog from './CloudSyncDialog.vue'
import RuntimeSettings from './RuntimeSettings.vue'
import AiPractice from './AiPractice.vue'
import PageGallery from './PageGallery.vue'
import { appearanceCss, normalizeAppearance, positionCue } from './subtitleAppearance'
import type { VideoChapter } from './chapters'
import { createSubtitlePoller, needsSubtitleUpdate, selectSubtitleSource, setSubtitleVisibility, SubtitleRequestError, toWebVtt } from './subtitles'
import type { SubtitleJob, SubtitleMode, SubtitleTarget } from './subtitles'
import { mediaFingerprint } from './mindMap'
import { uploadFile } from './nativeMedia'
import type { SelectedMedia } from './nativeMedia'
import { mediaBindingState, latestRequests } from './mediaBinding'
import { resolveMediaIdentity } from './mediaIdentityCache'
import {rememberCompatibility,lookupCompatibility,forgetCompatibility} from './compatibilityCache'
import type { RequestTicket } from './mediaBinding'
import type { MindMapNode as MindNode, MindMapResult } from './mindMap'

type Segment = { id: string; startMs: number; endMs: number; text: string }
type OcrBlock = { text: string; score: number; polygon: number[][] }
type ImageAnalysis = { status: string; title: string; content: string; visualElements: string[]; uncertainties: string[] }
type VisualEvidence = { frameTimeMs: number; ocrBlocks: OcrBlock[]; imageAnalysis?: ImageAnalysis }
type OcrLine = { text: string; sourceFrameTimeMs: number; sourceBlockIndex: number }
type PageGroup = { pageIndex: number; firstFrameTimeMs: number; lastFrameTimeMs: number;
  memberFrameTimesMs: number[]; representativeFrameTimesMs: number[];
  decision: string; decisionReason: string; ocrLines: OcrLine[]; imageAnalysis?: ImageAnalysis; textAnalysis?: ImageAnalysis; groupUnderstanding?: Record<string, unknown> | null }
type Review = { status: string; resampledTimesMs: number[]; concerns: string[] }
type TranscriptionJob = { id: string; status: string; progress?: AnalysisProgress | null; result?: { language: string; segments: Segment[]; visualEvidence?: VisualEvidence[]; pageGroups?: PageGroup[]; mindMap?: MindMapResult; visualAnalysisMode?: 'ocr_only' | 'both'; ocrModelId?: string; imageModelId?: string; review?: Review }; error?: string }
type RightTab = 'map' | 'practice' | 'transcript' | 'slides' | 'notes' | 'history'

import {groupExamples} from './exampleTimeline'
import {compactKnowledgeMap} from './mindMap'
import {serverHistory} from './history'
import type {HistoryStatus, HistoryEntry} from './history'

const jobIdPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i

function savedMediaName(id: string): string {
  try {
    const media = JSON.parse(localStorage.getItem(`analysisMedia:${id}`) ?? 'null')
    return typeof media?.name === 'string' ? media.name : ''
  } catch { return '' }
}

function readHistory(): HistoryEntry[] {
  let entries: HistoryEntry[] = []
  try {
    const saved = JSON.parse(localStorage.getItem('analysisHistory:v1') ?? '[]')
    if (Array.isArray(saved)) entries = saved.filter(item => jobIdPattern.test(item?.id) &&
      typeof item.name === 'string' && typeof item.addedAt === 'string' &&
      ['unknown', 'queued', 'processing', 'completed', 'failed', 'expired'].includes(item.status))
  } catch { /* An invalid local list must not block the app. */ }
  const lastId = localStorage.getItem('lastAnalysisId') ?? ''
  const knownIds = new Set(entries.map(item => item.id))
  const oldIds = [lastId, ...Array.from({ length: localStorage.length }, (_, index) => localStorage.key(index) ?? '')
    .filter(key => key.startsWith('analysisMedia:')).map(key => key.slice('analysisMedia:'.length))]
  for (const id of oldIds) {
    if (!jobIdPattern.test(id) || knownIds.has(id)) continue
    entries.push({ id, name: savedMediaName(id) || '历史分析',
      addedAt: new Date().toISOString(), status: 'unknown' })
    knownIds.add(id)
  }
  return entries
}

const runtimeSettingsOpen=ref(false)
onMounted(() => {
  if (window.framewiseDesktop) void window.framewiseDesktop.status().then(status => {
    if (status.phase !== 'ready' || !status.settings?.hasKey || !['ready', 'installed'].includes(status.models?.state || '')) runtimeSettingsOpen.value = true
  }).catch(() => { runtimeSettingsOpen.value = true })
})
const cloudSyncOpen=ref(false)
const apiBase = API_ORIGIN + '/api'
type WorkspaceAppearance = 'acrylic' | 'blue' | 'classic'
const appearanceOptions: { value: WorkspaceAppearance; label: string }[] = [
  { value: 'acrylic', label: '亚克力' }, { value: 'blue', label: '蓝紫' }, { value: 'classic', label: '简洁' },
]
function loadWorkspaceAppearance(): WorkspaceAppearance {
  try {
    const value = localStorage.getItem('framewise:appearance:v1')
    return value === 'acrylic' || value === 'classic' ? value : 'blue'
  } catch { return 'blue' }
}
const workspaceAppearance = ref<WorkspaceAppearance>(loadWorkspaceAppearance())
watch(workspaceAppearance, value => {
  try { localStorage.setItem('framewise:appearance:v1', value) } catch { /* Keep switching available when browser storage is unavailable. */ }
})
const ambientHidden = ref(document.hidden)
function syncAmbientVisibility() { ambientHidden.value = document.hidden }
onMounted(() => document.addEventListener('visibilitychange', syncAmbientVisibility))
onUnmounted(() => document.removeEventListener('visibilitychange', syncAmbientVisibility))

const video = ref<HTMLVideoElement | null>(null)
const transcriptList = ref<HTMLElement | null>(null)
const sidebarTranscriptList = ref<HTMLElement | null>(null)
const rightTab = ref<RightTab>('map')
const overviewState=ref({status:'not_requested',revision:''})
const rightTabOrder: RightTab[] = ['map', 'practice', 'transcript', 'slides', 'notes', 'history']
const transcriptQuery = ref('')
const studyNotesPanel = ref<InstanceType<typeof StudyNotes> | null>(null)
const analysisHistory = ref<HistoryEntry[]>(readHistory())
const deletingHistoryId = ref('')
const historyError = ref('')
const historyLoading = ref(false), historySynced = ref(false)
let historyController:AbortController|null = null, historyGeneration = 0
function cacheHistory(){try{localStorage.setItem('analysisHistory:v1',JSON.stringify(analysisHistory.value))}catch{/* Keep server results when storage is unavailable. */}}
async function refreshHistory(){
 if(deletingHistoryId.value||historyLoading.value)return
 const generation=++historyGeneration
 historyController?.abort();const controller=new AbortController();historyController=controller;historyLoading.value=true
 let timedOut=false;let timeout:ReturnType<typeof setTimeout>|undefined
 try{
  await waitForRuntimeReady(window.framewiseDesktop,{signal:controller.signal,current:()=>generation===historyGeneration&&!controller.signal.aborted},{expectedOrigin:API_ORIGIN})
  if(controller.signal.aborted||generation!==historyGeneration)return
  timeout=setTimeout(()=>{timedOut=true;controller.abort()},15000)
  const response=await fetch(`${apiBase}/transcriptions`,{signal:controller.signal})
  if(!response.ok)throw new Error(`HTTP ${response.status}`)
  const data=await response.json()
  if(controller.signal.aborted||generation!==historyGeneration)return
  const cached=analysisHistory.value.map(item=>({...item,name:savedMediaName(item.id)||item.name}))
  analysisHistory.value=serverHistory(data,cached);historySynced.value=true;historyError.value='';cacheHistory()
 }catch(e){if((timedOut||!controller.signal.aborted)&&generation===historyGeneration)historyError.value=window.framewiseDesktop?'暂时无法读取本机历史记录，当前显示上次缓存。请在服务就绪后重试。':'无法同步服务器历史，当前显示上次缓存。请稍后刷新。'}
 finally{clearTimeout(timeout);if(generation===historyGeneration){historyLoading.value=false;historyController=null}}
}
watch(rightTab,tab=>{if(tab==='history')void refreshHistory()})
let historyTimer:ReturnType<typeof setInterval>|undefined
function focusHistory(){void refreshHistory()}
function nativeRuntimeState(event: Event) {
 const detail = (event as CustomEvent<{phase?: string; apiOrigin?: string}>).detail
 if (!window.framewiseDesktop || detail?.phase !== 'ready') return
 const previousOrigin = API_ORIGIN
 if (!setApiOrigin(detail.apiOrigin)) return
 if (API_ORIGIN !== previousOrigin) {
  setApiOrigin(previousOrigin)
  error.value = '本机服务地址已变化，请保存笔记并重新打开软件，随后继续学习。'
  runtimeSettingsOpen.value = true
  return
 }
 if (existingJobId.value && !isAnalysisPending.value && ['read_failed','interrupted'].includes(analysisState.value)) void loadExistingAnalysis()
 else if (!existingJobId.value && !isAnalysisPending.value) void refreshHistory()
}
onMounted(()=>{void refreshHistory();window.addEventListener('focus',focusHistory);window.addEventListener('framewise-runtime-state',nativeRuntimeState);historyTimer=setInterval(()=>{if(rightTab.value==='history'&&!document.hidden&&!historyLoading.value)void refreshHistory()},15000)})
onUnmounted(()=>{++historyGeneration;historyController?.abort();clearInterval(historyTimer);window.removeEventListener('focus',focusHistory);window.removeEventListener('framewise-runtime-state',nativeRuntimeState)})

const selectedFile = ref<SelectedMedia | null>(null)
const selectedFingerprint = ref('')
const workspaceOpen = ref(false)
const personSelectionMode = ref<PersonSelectionMode>('off')
function updatePersonSelection(mode:PersonSelectionMode) {
 personSelectionMode.value=mode
 savePersonSelection(localStorage,selectedFingerprint.value,mode)
}
const ignoredRegion = ref<IgnoreSetting|null>(null)
const analysisRegion = ref<IgnoreSetting|null>(null)
watch(selectedFingerprint, fingerprint => {
  personSelectionMode.value=loadPersonSelection(localStorage,fingerprint)
  try { ignoredRegion.value = fingerprint ? normalizeIgnoreSetting(JSON.parse(localStorage.getItem(`videoIgnoreRegion:v1:${fingerprint}`) ?? 'null')) : null }
  catch { ignoredRegion.value = null }
  try { analysisRegion.value=fingerprint?normalizeIgnoreSetting(JSON.parse(localStorage.getItem(`videoAnalysisRegion:v1:${fingerprint}`)??'null'),true):null }catch {analysisRegion.value=null}
})
function saveIgnoredRegion(region: IgnoreSetting|null) {
  ignoredRegion.value = normalizeIgnoreSetting(region)
  if (!selectedFingerprint.value) return
  try {
    const key = `videoIgnoreRegion:v1:${selectedFingerprint.value}`
    if (ignoredRegion.value) localStorage.setItem(key, JSON.stringify(ignoredRegion.value))
    else localStorage.removeItem(key)
  } catch { /* Keep the current setting even when browser storage is unavailable. */ }
}
function saveAnalysisRegion(region:IgnoreSetting|null){
 analysisRegion.value=normalizeIgnoreSetting(region,true)
 if(!selectedFingerprint.value)return
 try{const key=`videoAnalysisRegion:v1:${selectedFingerprint.value}`;if(analysisRegion.value)localStorage.setItem(key,JSON.stringify(analysisRegion.value));else localStorage.removeItem(key)}catch{}
}
function openVideoWorkspace() { video.value?.pause(); workspaceOpen.value = true }

const selectionRequests = latestRequests()
const analysisRequests = latestRequests()
const mindMapRequests = latestRequests()
const checkingMedia = ref(false)
let changingAnalysisId = false
const videoUrl = ref('')
const compatibilityBusy = ref(false)
const compatibilityMessage = ref('')
const compatibilityId = ref('')
const compatibilityActive = ref(false)
let originalVideoUrl = ''
let compatibilityGeneration = 0
const cancelledCompatibilityGenerations = new Set<number>()
let compatibilityUpload: XMLHttpRequest | null = null

function clearCompatibility() {
  compatibilityGeneration++
  compatibilityUpload?.abort()
  compatibilityUpload = null
  compatibilityId.value = ''
  compatibilityBusy.value = false
  compatibilityActive.value = false
  compatibilityMessage.value = ''
  if (originalVideoUrl && originalVideoUrl !== videoUrl.value) URL.revokeObjectURL(originalVideoUrl)
  originalVideoUrl = ''
}
// Navigation releases this player's state, never the server's reusable copy.
watch(selectedFile, () => clearCompatibility(), { flush: 'sync' })
function cancelCompatibility() {
  if(compatibilityBusy.value)cancelledCompatibilityGenerations.add(compatibilityGeneration)
  const id=compatibilityId.value,file=selectedFile.value
  if(file&&selectedFingerprint.value)forgetCompatibility(localStorage,{size:file.size,fingerprint:selectedFingerprint.value},id||undefined)
  clearCompatibility()
  if(id)void fetch(`${apiBase}/compatibility/${id}`,{method:'DELETE'}).catch(()=>{})
}
async function restoreCompatibility() {
  const file=selectedFile.value,fingerprint=selectedFingerprint.value,generation=compatibilityGeneration
  if(!file||!fingerprint||compatibilityActive.value||compatibilityBusy.value||compatibilityId.value)return
  try{
    const cached=await lookupCompatibility(localStorage,{size:file.size,fingerprint},fetch,apiBase)
    if(generation!==compatibilityGeneration||selectedFile.value!==file||!cached)return
    if(cached.status!=='completed'){void generateCompatibility();return}
    originalVideoUrl=videoUrl.value;compatibilityId.value=cached.id;compatibilityActive.value=true
    await switchPlayback(`${apiBase}/compatibility/${cached.id}/video`)
    if(generation===compatibilityGeneration)compatibilityMessage.value='已复用本视频的兼容副本（保留72小时）'
  }catch{if(generation===compatibilityGeneration)compatibilityMessage.value='已有兼容副本暂时无法读取，点击兼容播放可重试'}
}

async function switchPlayback(src: string) {
  const player = video.value
  const state = player ? { time: player.currentTime, paused: player.paused, volume: player.volume,
    muted: player.muted, rate: player.playbackRate } : null
  player?.pause()
  videoUrl.value = src
  await nextTick()
  const target = video.value
  if (!target || !state) return
  const restore = () => {
    if (videoUrl.value !== src) return
    target.currentTime = Math.min(state.time, target.duration || state.time)
    target.volume = state.volume; target.muted = state.muted; target.playbackRate = state.rate
    if (!state.paused) void target.play().catch(() => { compatibilityMessage.value = '兼容视频已就绪，请点击播放' })
  }
  if (target.readyState >= 1) restore()
  else target.addEventListener('loadedmetadata', restore, { once: true })
}

async function generateCompatibility() {
  if (!selectedFile.value || compatibilityBusy.value) return
  if (compatibilityId.value && originalVideoUrl) {
    compatibilityActive.value = !compatibilityActive.value
    await switchPlayback(compatibilityActive.value ? `${apiBase}/compatibility/${compatibilityId.value}/video` : originalVideoUrl)
    compatibilityMessage.value = compatibilityActive.value ? '正在使用 H.264 兼容副本' : '正在使用原视频'
    return
  }
  const file = selectedFile.value
  const generation = ++compatibilityGeneration
  compatibilityBusy.value = true
  compatibilityMessage.value = '正在检查后台显卡编码能力…'
  try {
    const identity={size:file.size,fingerprint:selectedFingerprint.value}
    const cached=await lookupCompatibility(localStorage,identity,fetch,apiBase)
    if(generation!==compatibilityGeneration)return
    let job: {id:string}
    if(cached){job=cached;compatibilityMessage.value='正在恢复已有兼容副本…'}
    else {
      const capabilityResponse = await fetch(`${apiBase}/compatibility/capabilities`)
      if (!capabilityResponse.ok) throw new Error('无法连接后台转码服务')
      const capability = await capabilityResponse.json()
      if (generation !== compatibilityGeneration) return
      if (!capability.available) throw new Error(capability.error || '后台编码不可用')
      const compatibilityFile=await uploadFile(file)
      if(generation !== compatibilityGeneration)return
      job = await new Promise((resolve, reject) => {
        const request = new XMLHttpRequest()
        compatibilityUpload = request
        request.open('POST', `${apiBase}/compatibility`)
        request.responseType = 'json'
        request.upload.onprogress = event => {
          if (generation === compatibilityGeneration) compatibilityMessage.value = event.lengthComputable
            ? `上传用于转码：${Math.round(event.loaded / event.total * 100)}%` : '正在上传用于转码…'
        }
        request.onerror = () => reject(new Error('上传失败，请检查后台连接'))
        request.onabort = () => reject(new Error('已取消'))
        request.onload = () => request.status === 202 ? resolve(request.response) : reject(new Error('无法创建转码任务，请检查后台是否忙碌'))
        const form = new FormData(); form.append('file', compatibilityFile); request.send(form)
      })
      // Save before testing navigation generation, so a completed upload is not lost.
      rememberCompatibility(localStorage,identity,job.id)
    }
    compatibilityUpload = null
    if (generation !== compatibilityGeneration) {
      if(cancelledCompatibilityGenerations.has(generation)){
        forgetCompatibility(localStorage,identity,job.id)
        void fetch(`${apiBase}/compatibility/${job.id}`,{method:'DELETE'}).catch(()=>{})
      }
      return
    }
    compatibilityId.value = job.id
    for (;;) {
      if (generation !== compatibilityGeneration) return
      const response = await fetch(`${apiBase}/compatibility/${job.id}`)
      if (!response.ok) throw new Error('查询转码状态失败')
      const result = await response.json()
      if (generation !== compatibilityGeneration) return
      if (result.status === 'failed') throw new Error(result.error || '显卡转码失败')
      if (result.status === 'completed') break
      compatibilityMessage.value = `显卡转码：${result.progress || 0}%（无需重新分析）`
      await new Promise(resolve => setTimeout(resolve, 1000))
    }
    originalVideoUrl = videoUrl.value
    compatibilityActive.value = true
    await switchPlayback(`${apiBase}/compatibility/${job.id}/video`)
    if(generation===compatibilityGeneration)compatibilityMessage.value = '正在使用 H.264 兼容副本（72 小时后自动清理）'
  } catch (cause) {
    if (generation === compatibilityGeneration) {
      compatibilityMessage.value = cause instanceof Error ? cause.message : '显卡转码失败'
      compatibilityId.value = ''
      // A transient read failure must not destroy a successfully created copy.
    }
  } finally {
    if (generation === compatibilityGeneration) compatibilityBusy.value = false
    cancelledCompatibilityGenerations.delete(generation)
  }
}
const filename = ref('')
const analysisState = ref('')
const analysisProgress = ref<AnalysisProgress|null>(null)
const status = ref('请选择本地视频')
const transcript = ref<Segment[]>([])
const visualEvidence = ref<VisualEvidence[]>([])
const pageGroups = ref<PageGroup[]>([])
const rawMindMap = ref<MindMapResult | null>(null)
const mindMap = computed(()=>rawMindMap.value?{...rawMindMap.value,root:compactKnowledgeMap(rawMindMap.value.root)}:null)
const mindMapFailureReasons = computed(() => mindMap.value?.status === 'failed'
  ? [...new Set((mindMap.value.uncertainties ?? []).filter(reason => /节点来源校验失败|已拒绝|导图失败|导图请求或回复失败/.test(reason)))].slice(0, 3)
  : [])
// Keep citation data for playback, but temporarily hide the panel below the map.
const showMindMapEvidence = false
const selectedMindNode = ref<MindNode | null>(null)
const expandedMap = ref(false)
const activeSegmentId = ref('')
const generatingMindMap = ref(false)
const isAnalysisPending = ref(false)
const analysisReadOnly = ref(false)
let loadedAnalysisId = ''
// Only whole-course image/text synthesis is exposed for new/manual generation.
const mindMapMode = 'direct' as const
const groupedAnalysis = false
const visualAnalysisMode = ref<'ocr_only' | 'both'>('both')
const coarseChangePercent = ref('3')
const coarseSampleSeconds = ref(2)
const advancedOpen = ref(false)
const review = ref<Review | null>(null)
const failedJobId = ref('')
const existingJobId = ref('')
watch([mindMap, selectedFile, existingJobId], () => { expandedMap.value = false })
const serverMedia = ref<Record<string, {size:number;fingerprint:string}>>({})
const playbackNotice = ref('')
const mediaConflicts=ref(new Set<string>())
const currentBinding = computed(() => {
  if(mediaConflicts.value.has(existingJobId.value))return 'unverified'
  return selectedFile.value && existingJobId.value
    ? mediaBindingState(JSON.stringify(serverMedia.value[existingJobId.value] ?? null), selectedFile.value.size, selectedFingerprint.value)
    : 'unverified'
})
const confirmedMedia = computed(() => !!selectedFile.value && !checkingMedia.value && !!existingJobId.value && currentBinding.value === 'matched')
const associationVisible = computed(() => !!selectedFile.value && !!existingJobId.value && !!(transcript.value.length || rawMindMap.value || pageGroups.value.length))
watch([existingJobId, selectedFingerprint], () => { playbackNotice.value = mediaConflicts.value.has(existingJobId.value)?'本地与后端的视频指纹记录冲突，已停止关联。':'' })
async function readServerMedia(id:string, signal?:AbortSignal) {
  return resolveMediaIdentity(id,localStorage,fetch,{signal,
    onUpdate:media=>{mediaConflicts.value.delete(id);if(media)serverMedia.value[id]=media;else delete serverMedia.value[id]},
    onConflict:()=>{mediaConflicts.value.add(id);delete serverMedia.value[id];if(existingJobId.value===id)playbackNotice.value='本地与后端的视频指纹记录冲突，已停止关联。请核对历史记录与原视频。'},
    onError:()=>{/* A valid automatic cache remains usable while the backend is unavailable. */}
  }).then(media=>{if(media&&!mediaConflicts.value.has(id))serverMedia.value[id]=media;return media})
}
async function restoreCourseMedia(id:string, request:RequestTicket) {
  let media
  try{media=await readServerMedia(id,request.signal)}catch(error){
    if(!request.current())return
    delete serverMedia.value[id]
    playbackNotice.value='课程视频指纹暂时无法读取，历史分析仍可查看，请稍后重试。'
    return
  }
  if(!request.current()||existingJobId.value!==id)return
  if(!media){playbackNotice.value='旧记录的原视频已清理，无法自动补回指纹；本记录暂不能联动视频。';return}
  if(selectedFile.value && mediaBindingState(JSON.stringify(media),selectedFile.value.size,selectedFingerprint.value)==='matched'){void restoreCompatibility();return}
  if(!window.framewiseMedia){playbackNotice.value='请选择本课原视频，软件会自动核对。';return}
  const restored=await window.framewiseMedia.restore(media.fingerprint)
  if(!request.current()||existingJobId.value!==id)return
  if(!restored){playbackNotice.value='未找到已记住的本课原视频，文件可能已移动或删除，请重新选择，软件将自动核对。';return}
  if(restored.size!==media.size||restored.fingerprint!==media.fingerprint)return
  video.value?.pause()
  const previousUrl=videoUrl.value
  selectedFile.value=restored
  selectedFingerprint.value=restored.fingerprint
  videoUrl.value=restored.url
  filename.value=restored.name
  currentPlaybackMs.value=0
  if(previousUrl.startsWith('blob:'))URL.revokeObjectURL(previousUrl)
  void restoreCompatibility()
}
function setAnalysisId(id: string) {
  changingAnalysisId = true
  existingJobId.value = id
  changingAnalysisId = false
}
const error = ref('')
const unavailableFrames = ref<Set<number>>(new Set())
const currentPlaybackMs = ref(0)
const subtitleEnabled = ref(true)
const subtitleAppearance=ref(normalizeAppearance((()=>{try{return JSON.parse(localStorage.getItem('subtitleAppearance:v1')??'null')}catch{return null}})()))
const cueStyleElement=document.createElement('style')
document.head.append(cueStyleElement)
watch(subtitleAppearance,value=>{
  cueStyleElement.textContent=appearanceCss(value)
  try{localStorage.setItem('subtitleAppearance:v1',JSON.stringify(value))}catch{/* Storage may be unavailable. */}
  syncSubtitleVisibility()
},{deep:true,immediate:true})
const subtitleUrl = ref('')
const sourceLanguage = ref('und')
const videoChapters = ref<VideoChapter[]>([])
const chapterStatus = ref('not_requested')
let chapterController: AbortController | null = null
watch([existingJobId, () => transcript.value.length], async ([id, count]) => {
  chapterController?.abort()
  videoChapters.value = []
  chapterStatus.value = 'not_requested'
  if (!id || !count) return
  const controller = new AbortController()
  chapterController = controller
  let errors = 0
  try {
    for (let attempt = 0; attempt < 900 && !controller.signal.aborted; attempt++) {
      try {
        let response = await fetch(`${apiBase}/transcriptions/${id}/chapters`, { signal: controller.signal })
        if (!response.ok) throw new SubtitleRequestError(response.status)
        let job = await response.json()
        if (job.status === 'not_requested') {
          response = await fetch(`${apiBase}/transcriptions/${id}/chapters`, { method: 'POST', signal: controller.signal })
          if (!response.ok) throw new SubtitleRequestError(response.status)
          job = await response.json()
        }
        if (controller.signal.aborted) return
        errors = 0
        chapterStatus.value = job.status
        if (job.status === 'completed') { videoChapters.value = job.result?.chapters ?? []; return }
        if (job.status === 'failed') return
      } catch (cause) {
        if (controller.signal.aborted) return
        const permanent = cause instanceof SubtitleRequestError && cause.status >= 400 && cause.status < 500 && ![408,429].includes(cause.status)
        if (permanent || ++errors >= 3) throw cause
      }
      await new Promise(resolve => setTimeout(resolve, 1500))
    }
    if (!controller.signal.aborted) chapterStatus.value = 'failed'
  } catch { if (!controller.signal.aborted) chapterStatus.value = 'failed' }
})
onUnmounted(() => chapterController?.abort())
const subtitleTargetLanguage = ref<SubtitleTarget>('source')
const subtitleMode = ref<SubtitleMode>('original')
const subtitleJob = ref<SubtitleJob | null>(null)
const subtitleCourseId = ref('')
const subtitleRequestError = ref('')
const requestingSubtitles = ref(false)
let subtitleRequestGeneration = 0
const selectedSubtitles = computed(() => selectSubtitleSource(transcript.value, sourceLanguage.value, subtitleJob.value, subtitleMode.value))
const aiSubtitlesAvailable = computed(() => selectSubtitleSource(transcript.value, sourceLanguage.value, subtitleJob.value, 'ai').mode === 'ai')
const subtitleChanges = computed(() => subtitleJob.value?.result?.changes ?? [])
const subtitleChangeById = computed(() => new Map(subtitleChanges.value.map(change => [change.segmentId, change])))
const subtitleIsTranslation = computed(() => subtitleJob.value?.result?.mode === 'translation')
const subtitleNeedsUpdate = computed(() => needsSubtitleUpdate(subtitleJob.value))
const canGenerateSubtitles = computed(() => !!transcript.value.length && subtitleCourseId.value === existingJobId.value
  && ['not_requested', 'completed', 'partial', 'failed'].includes(subtitleJob.value?.status ?? '') && !isAnalysisPending.value && !requestingSubtitles.value)
const subtitleStatusMessage = computed(() => {
  if (!subtitleCourseId.value) return ''
  if (subtitleRequestError.value) return 'AI 字幕暂时不可用；原文仍可使用。'
  if (requestingSubtitles.value) return '正在提交 AI 字幕任务…'
  const target = subtitleTargetLanguage.value === 'en' ? '英文' : subtitleTargetLanguage.value === 'zh' ? '中文' : '同语言'
  switch (subtitleJob.value?.status) {
    case 'awaiting_source': return 'AI 字幕等待语音与课件分析；课程分析继续进行。'
    case 'queued': return `AI ${target}字幕排队中；原文可先使用。`
    case 'processing': return `正在生成 AI ${target}字幕；原文可先使用。`
    case 'partial': return 'AI 字幕部分完成；已通过校验的内容可使用，其余保留原文。'
    case 'completed': return subtitleIsTranslation.value ? `AI ${subtitleJob.value?.result?.targetLanguage === 'en' ? '英文' : '中文'}翻译字幕已生成。`
      : `AI 校正字幕已生成 · ${subtitleChanges.value.length} 处调整。`
    case 'failed': return 'AI 字幕生成失败；原文仍可使用。'
    case 'unsupported': return 'AI 字幕目前支持中文和英文；原文仍可使用。'
    case 'not_requested': return 'AI 字幕按需生成；点击“生成 AI 字幕”后才开始校正或翻译。'
    default: return '正在读取 AI 字幕状态…'
  }
})
const subtitlePoller = createSubtitlePoller({
  fetchJob: async (id, target, signal) => {
    const response = await fetch(`${apiBase}/transcriptions/${id}/subtitles?targetLanguage=${target}`, { signal })
    if (!response.ok) throw new SubtitleRequestError(response.status)
    return await response.json() as SubtitleJob
  },
  onJob: job => { subtitleJob.value = job; subtitleRequestError.value = '' },
  onError: message => { subtitleRequestError.value = message }
})

function clearSubtitleJob() {
  subtitleRequestGeneration++
  subtitlePoller.stop()
  subtitleCourseId.value = ''
  subtitleJob.value = null
  subtitleRequestError.value = ''
  requestingSubtitles.value = false
  subtitleMode.value = 'original'
}

function readSubtitleJob(id: string) {
  clearSubtitleJob()
  subtitleCourseId.value = id
  void subtitlePoller.start(id, subtitleTargetLanguage.value)
}

async function generateSubtitles() {
  if (!canGenerateSubtitles.value) return
  const id = subtitleCourseId.value
  const target = subtitleTargetLanguage.value
  const token = ++subtitleRequestGeneration
  requestingSubtitles.value = true
  subtitleRequestError.value = ''
  try {
    const response = await fetch(`${apiBase}/transcriptions/${id}/subtitles`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ targetLanguage: target,
        force: ['completed', 'partial'].includes(subtitleJob.value?.status ?? '') })
    })
    if (token !== subtitleRequestGeneration) return
    if (!response.ok) throw new Error(`HTTP ${response.status}`)
    const job = await response.json() as SubtitleJob
    if (token !== subtitleRequestGeneration) return
    subtitleJob.value = job
    void subtitlePoller.start(id, target)
  } catch (cause) {
    if (token === subtitleRequestGeneration) subtitleRequestError.value = cause instanceof Error ? cause.message : String(cause)
  } finally {
    if (token === subtitleRequestGeneration) requestingSubtitles.value = false
  }
}

watch(subtitleTargetLanguage, () => {
  const id = subtitleCourseId.value
  if (id) {
    const mode=subtitleMode.value
    readSubtitleJob(id)
    subtitleMode.value=mode
  }
})
watch(existingJobId, (id, previous) => {
  if (!changingAnalysisId && id !== previous) {
    selectionRequests.invalidate()
    checkingMedia.value = false
    invalidateAnalysisRequests()
    clearLoadedAnalysis()
  }
  if (subtitleCourseId.value && id !== subtitleCourseId.value) clearSubtitleJob()
}, { flush: 'sync' })
function syncSubtitleVisibility() {
  setSubtitleVisibility(video.value, subtitleEnabled.value)
  const track = video.value?.textTracks[0]
  const cues = track?.cues
  const active = new Set(track?.activeCues ? Array.from(track.activeCues) : [])
  if (cues && track) for (const cue of Array.from(cues)) {
    if (cue instanceof VTTCue) {
      const changed=cue.snapToLines||cue.line!==subtitleAppearance.value.vertical
      positionCue(cue,subtitleAppearance.value)
      // Chromium may cache the active cue's layout while paused.
      if(changed&&active.has(cue)){track.removeCue(cue);track.addCue(cue)}
    }
  }
  if (video.value?.textTracks[0]) {
    video.value.textTracks.addEventListener('change', refreshSubtitleToggle)
  }
}
function refreshSubtitleToggle() {
  const track = video.value?.textTracks[0]
  if (track?.cues?.length) subtitleEnabled.value = track.mode === 'showing'
}
watch(() => selectedSubtitles.value.segments, segments => {
  if (subtitleUrl.value) URL.revokeObjectURL(subtitleUrl.value)
  subtitleUrl.value = segments.length ? URL.createObjectURL(new Blob([toWebVtt(segments)], { type: 'text/vtt;charset=utf-8' })) : ''
})
watch([subtitleEnabled, subtitleUrl, video], async () => {
  await nextTick()
  syncSubtitleVisibility()
})
watch(video, (_, previous) => previous?.textTracks.removeEventListener('change', refreshSubtitleToggle))
const activeSlide = computed(() => {
  if (!pageGroups.value.length) return null
  return [...pageGroups.value].reverse().find(page => page.firstFrameTimeMs <= currentPlaybackMs.value) ?? pageGroups.value[0]
})
const activeLegacyFrame = computed(() => {
  if (!visualEvidence.value.length) return null
  return [...visualEvidence.value].reverse().find(frame => frame.frameTimeMs <= currentPlaybackMs.value) ?? visualEvidence.value[0]
})
const filteredTranscript = computed(() => transcript.value.filter(segment => segment.text.includes(transcriptQuery.value.trim())))
const noteScopes = computed(() => (transcript.value.length || mindMap.value) && (!selectedFile.value || confirmedMedia.value)
  ? [existingJobId.value, selectedFingerprint.value].filter(Boolean)
  : selectedFile.value ? [selectedFingerprint.value].filter(Boolean) : [])
const exampleTimeline = computed(()=>groupExamples(mindMap.value?.examples,transcript.value,mindMap.value?.promptVersion))
const currentHistoryName = computed(() => analysisHistory.value.find(entry => entry.id === existingJobId.value)?.name ?? '')

function rememberAnalysis(id: string, status: HistoryStatus, name = '') {
  const previous = analysisHistory.value.find(entry => entry.id === id)
  const entry: HistoryEntry = { id, name: name || previous?.name || savedMediaName(id) || '历史分析',
    addedAt: previous?.addedAt ?? new Date().toISOString(), status }
  analysisHistory.value = [entry, ...analysisHistory.value.filter(item => item.id !== id)]
  cacheHistory()
}

function historyStatusLabel(status: HistoryStatus) {
  return { unknown: '未查询', queued: '排队中', processing: '分析中', completed: '已完成', failed: '失败', expired: '已过期' }[status]
}

function clearLoadedAnalysis() {
  loadedAnalysisId = ''
  analysisState.value = ''
  analysisProgress.value = null
  clearSubtitleJob()
  sourceLanguage.value = 'und'
  transcript.value = []
  visualEvidence.value = []
  pageGroups.value = []
  rawMindMap.value = null
  selectedMindNode.value = null
  activeSegmentId.value = ''
  review.value = null
  failedJobId.value = ''
  videoChapters.value = []
  chapterStatus.value = 'not_requested'
  chapterController?.abort()
}
function invalidateAnalysisRequests() {
  analysisRequests.invalidate()
  mindMapRequests.invalidate()
  isAnalysisPending.value = false
  analysisReadOnly.value = false
  generatingMindMap.value = false
}
async function chooseVideo(event: Event) {
  const input = event.target as HTMLInputElement
  const file = input.files?.[0]
  if (!file) return
  input.value = ''
  const request = selectionRequests.begin()
  const previousId = existingJobId.value
  checkingMedia.value = true
  error.value = ''
  status.value = '正在核对本地媒体文件…'
  try {
    const fingerprint = await mediaFingerprint(file)
    const native = window.framewiseMedia ? await window.framewiseMedia.register(file) : null
    if(native && (native.fingerprint!==fingerprint||native.size!==file.size))throw new Error('视频在核对时发生变化')
    const expected = previousId ? await readServerMedia(previousId,request.signal) : null
    if (!request.current()) return
    const binding = mediaBindingState(JSON.stringify(expected), file.size, fingerprint)
    const sameFile = selectedFile.value?.size === file.size && selectedFingerprint.value === fingerprint
    // Explicitly selecting a different video starts a separate workspace.
    if (previousId && binding === 'mismatch') {
      invalidateAnalysisRequests()
      setAnalysisId('')
      clearLoadedAnalysis()
      localStorage.removeItem('lastAnalysisId')
    }
    if (!sameFile) {
      video.value?.pause()
      const previousUrl = videoUrl.value
      selectedFile.value = file
      selectedFingerprint.value = fingerprint
      videoUrl.value = URL.createObjectURL(file)
      filename.value = file.name
      currentPlaybackMs.value = 0
      if (previousUrl.startsWith('blob:')) URL.revokeObjectURL(previousUrl)
      void restoreCompatibility()
    }
    checkingMedia.value = false
    if (previousId && binding === 'matched') {
      localStorage.setItem('lastAnalysisId', previousId)
      status.value = sameFile ? '视频与历史记录匹配；已保留当前播放位置和课程结果' : '视频指纹匹配；已关联历史结果，可回放课程依据'
    } else if (previousId && binding === 'unverified') {
      status.value = '已保留视频和历史结果；该旧记录原视频已清理，无法自动核对，课程回放暂不联动'
    } else {
      status.value = previousId ? '视频指纹不匹配，已解除旧任务关联；当前视频可开始分析' : '本地视频已就绪；可上传进行分析'
    }
  } catch {
    if (request.current()) {
      error.value = '无法读取本地文件，已保留原有视频和历史结果，请重新选择'
      status.value = '文件核对未完成'
    }
  } finally {
    if (request.current()) checkingMedia.value = false
  }
}

async function waitForAnalysis(id: string, request: RequestTicket) {
    const started=Date.now()
    for (let attempt = 0; attempt < 1800; attempt++) {
      if (!request.current() || existingJobId.value !== id) return
      await readDelay(1000,request.signal)
      if (!request.current() || existingJobId.value !== id) return
      const job = await readCourseJson<TranscriptionJob>(`${apiBase}/transcriptions/${id}`,request,{onRetry:attempt=>{
        if(request.current()&&existingJobId.value===id){analysisState.value='reconnecting';status.value='课程连接暂时中断，正在重新读取…';console.info('[framewise:course-read]',{taskId:id,stage:'retry',attempt,elapsedMs:Date.now()-started})}
      }})
      if (!request.current() || existingJobId.value !== id) return
      if (['queued', 'processing', 'completed', 'failed', 'expired'].includes(job.status) &&
          analysisHistory.value.find(entry => entry.id === id)?.status !== job.status) {
        rememberAnalysis(id, job.status as HistoryStatus)
      }
      analysisState.value = job.status
      analysisProgress.value = job.progress ?? null
      status.value = job.status === 'queued' ? '等待分析任务…' : '正在分析…'
      if (job.status === 'expired') {
        failedJobId.value = ''
        throw new Error('此任务已过期，没有可读取的分析结果，请重新选择视频分析。')
      }
      if (job.status === 'failed') {
        failedJobId.value = id
        throw new Error(job.error || '分析失败')
      }
      if (job.status === 'completed') {
        loadedAnalysisId = id
        error.value = ''
        console.info('[framewise:course-read]',{taskId:id,stage:'completed',elapsedMs:Date.now()-started})
        unavailableFrames.value = new Set()
        transcript.value = job.result?.segments ?? []
        sourceLanguage.value = job.result?.language || 'und'
        visualEvidence.value = job.result?.visualEvidence ?? []
        pageGroups.value = job.result?.pageGroups ?? []
        rawMindMap.value = job.result?.mindMap ?? null
        selectedMindNode.value = null
        activeSegmentId.value = ''
        review.value = job.result?.review ?? null
        failedJobId.value = ''
        const pageStatuses = pageGroups.value.map(page =>
          page.groupUnderstanding?.status ?? (job.result?.visualAnalysisMode === 'ocr_only' ? page.textAnalysis : page.imageAnalysis)?.status)
        const completedCount = pageStatuses.filter(value => value === 'completed').length
        const inferredCount = pageStatuses.filter(value => value === 'inferred').length
        const unverifiedCount = pageStatuses.filter(value => value === 'unverified').length
        const routeName = job.result?.visualAnalysisMode === 'ocr_only' ? '语音＋OCR 文字理解' : '语音＋图片理解'
        status.value = `分析完成：转写 ${transcript.value.length} 段；候选画面 ${visualEvidence.value.length} 张、归为 ${pageGroups.value.length} 页；OCR ${job.result?.ocrModelId || '未记录'}；${routeName}确认 ${completedCount} 页、含推导 ${inferredCount} 页、待核实 ${unverifiedCount} 页；导图${mindMap.value?.status === 'completed' ? '已生成' : mindMap.value?.status === 'failed' ? '部分失败' : '暂无'}`
        if (rawMindMap.value?.promptVersion?.startsWith('whole-course-group-evidence-direct-')) status.value = `分析完成：转写 ${transcript.value.length} 段；归为 ${pageGroups.value.length} 页；已跳过逐页解读，整课图文导图${rawMindMap.value.status === 'completed' ? '已生成' : '未完全生成，可重试'}`
        if (selectedFile.value && !confirmedMedia.value) {
          const binding = mediaBindingState(JSON.stringify(serverMedia.value[id] ?? null), selectedFile.value.size, selectedFingerprint.value)
          status.value += binding === 'unverified'
            ? '；已保留本地视频，记录缺少有效指纹，课程回放暂不联动'
            : '；已保留本地视频，指纹不匹配，课程回放暂不联动'
        }
        return
      }
    }
    throw new Error('等待分析超时')
}

const nativePreflightPending = ref(false)
async function nativeAnalysisReady(): Promise<boolean> {
  if (!window.framewiseDesktop) return true
  let timer: ReturnType<typeof setTimeout> | undefined
  try {
    const current = await Promise.race([window.framewiseDesktop.status(), new Promise<null>(resolve => { timer = setTimeout(() => resolve(null), 3500) })])
    const unavailable = unavailableAnalysisModules(current, personSelectionMode.value).length > 0
    const reason = !current || current.phase !== 'ready' ? '本机服务尚未就绪，请在设置中启动或重试。'
      : !current.settings?.hasKey ? '请先在设置中保存 DeepSeek API 密钥，再开始分析。'
      : !['ready', 'installed'].includes(current.models?.state || '') || unavailable ? '本地模型尚未就绪，请先在设置中下载或导入模型，并检查设备状态。'
      : current.apiOrigin && current.apiOrigin !== API_ORIGIN ? '本机服务地址已变化，请重新打开软件后再开始分析。' : ''
    if (reason) { error.value = reason; runtimeSettingsOpen.value = true; return false }
    return true
  } catch { error.value = '暂时无法检查本机环境，请在设置中重试或导出诊断。'; runtimeSettingsOpen.value = true; return false }
  finally { if (timer) clearTimeout(timer) }
}
async function runTranscription() {
  if (!selectedFile.value || isAnalysisPending.value || checkingMedia.value || nativePreflightPending.value) return
  if (window.framewiseDesktop) {
    const selectedBeforeCheck = selectedFile.value
    nativePreflightPending.value = true
    let ready = false
    try { ready = await nativeAnalysisReady() } finally { nativePreflightPending.value = false }
    if (!ready || selectedFile.value !== selectedBeforeCheck || checkingMedia.value || isAnalysisPending.value) return
  }
  const request = analysisRequests.begin()
  const file = selectedFile.value
  const fingerprint = selectedFingerprint.value
  if (file.size > 2 * 1024 * 1024 * 1024) {
    error.value = '当前最多上传 2 GB'
    return
  }
  isAnalysisPending.value = true
  error.value = ''
  clearSubtitleJob()
  transcript.value = []
  visualEvidence.value = []
  pageGroups.value = []
  rawMindMap.value = null
  selectedMindNode.value = null
  activeSegmentId.value = ''
  review.value = null
  failedJobId.value = ''
  setAnalysisId('')
  analysisState.value = 'uploading'
  analysisProgress.value = null
  status.value = '正在临时上传视频…'
  try {
    const form = new FormData()
    form.append('file', await uploadFile(file))
    form.append('visualAnalysisMode', visualAnalysisMode.value)
    form.append('coarseChangePercent', coarseChangePercent.value)
    form.append('coarseSampleSeconds', String(coarseSampleSeconds.value))
    form.append('personSelectionMode',personSelectionMode.value)
    form.append('groupedAnalysis', String(groupedAnalysis))
    form.append('mindMapMode', mindMapMode)
    if (analysisRegion.value||ignoredRegion.value) form.append('ignoredRegion',JSON.stringify(analysisRegion.value?{analysisRegion:analysisRegion.value,ignoredRegion:ignoredRegion.value}:ignoredRegion.value))
    form.append('aiSubtitles', 'false')
    form.append('subtitleTargetLanguage', subtitleTargetLanguage.value)
    const response = await fetch(`${apiBase}/transcriptions`, { method: 'POST', body: form, signal: request.signal })
    if (!response.ok) throw new Error(`上传失败：HTTP ${response.status}`)
    const created: TranscriptionJob = await response.json()
    if (!request.current()) return
    localStorage.setItem(`analysisMedia:${created.id}`, JSON.stringify({ name: file.name, size: file.size, fingerprint, bindingSource:'automatic_upload' }))
    setAnalysisId(created.id)
    localStorage.setItem('lastAnalysisId', created.id)
    rememberAnalysis(created.id, 'queued', file.name)
    await readServerMedia(created.id,request.signal)
    if(!request.current())return
    readSubtitleJob(created.id)
    analysisState.value = created.status
    await waitForAnalysis(created.id, request)
  } catch (cause) {
    if (!request.current()) return
    error.value = cause instanceof Error ? cause.message : String(cause)
    if (analysisState.value !== 'failed') analysisState.value = existingJobId.value ? 'read_failed' : 'upload_failed'
    status.value = '分析未完成'
  } finally {
    if (request.current()) isAnalysisPending.value = false
  }
}

async function cancelAnalysis() {
  const id = existingJobId.value
  if (!id || !isAnalysisPending.value) return
  try {
    const response = await fetch(`${apiBase}/transcriptions/${id}/cancel`, {method:'POST'})
    if (!response.ok) throw new Error(`取消失败：HTTP ${response.status}`)
    if (existingJobId.value !== id) return
    const cancellation = await response.json() as { agentNotified?: boolean }
    invalidateAnalysisRequests()
    analysisState.value = 'failed'
    failedJobId.value = id
    status.value = cancellation.agentNotified === false ? '已停止保存结果；模型服务尚未确认取消，可稍后重试' : '已取消分析，可保留原视频重试'
    rememberAnalysis(id, 'failed')
  } catch (cause) { error.value = cause instanceof Error ? cause.message : String(cause) }
}

async function loadExistingAnalysis() {
  if (isAnalysisPending.value && !analysisReadOnly.value) return
  const id = existingJobId.value.trim()
  if (!jobIdPattern.test(id)) {
    error.value = '请输入有效的分析编号'
    return
  }
  selectionRequests.invalidate()
  checkingMedia.value = false
  const request = analysisRequests.begin()
  const readStarted=Date.now()
  isAnalysisPending.value = true
  analysisReadOnly.value = true
  if (!analysisHistory.value.some(entry => entry.id === id)) rememberAnalysis(id, 'unknown')
  error.value = ''
  status.value = '正在读取已保存的分析结果…'
  if(loadedAnalysisId!==id)clearLoadedAnalysis()
  analysisState.value = 'reading'
  try {
    await waitForRuntimeReady(window.framewiseDesktop,request,{expectedOrigin:API_ORIGIN,onWaiting:()=>{if(request.current()&&existingJobId.value===id){analysisState.value='waiting_runtime';status.value='本机服务启动中，正在等待读取课程…'}}})
    if(!request.current()||existingJobId.value!==id)return
    analysisState.value='reading'
    status.value='正在读取已保存的分析结果…'
    readSubtitleJob(id)
    await restoreCourseMedia(id,request)
    if(!request.current())return
    await waitForAnalysis(id, request)
    if (request.current() && existingJobId.value === id) {
      localStorage.setItem('lastAnalysisId', id)
    }
  } catch (cause) {
    if (!request.current()) return
    console.warn('[framewise:course-read]',{taskId:id,stage:'failed',elapsedMs:Date.now()-readStarted,errorType:cause instanceof Error?cause.name:'Unknown'})
    error.value = cause instanceof Error ? cause.message : String(cause)
    if (analysisState.value !== 'failed') analysisState.value = 'read_failed'
    status.value = '未能读取分析结果'
  } finally {
    if (request.current()){isAnalysisPending.value=false;analysisReadOnly.value=false}
  }
}

async function openHistory(entry: HistoryEntry) {
  if (isAnalysisPending.value && !analysisReadOnly.value) return
  if (entry.status === 'expired') {historyError.value='此任务已过期，没有可读取的分析结果。可以删除这条记录，或重新选择视频分析。';return}
  if (existingJobId.value !== entry.id) {
    clearSubtitleJob()
    transcript.value = []
    visualEvidence.value = []
    pageGroups.value = []
    rawMindMap.value = null
    selectedMindNode.value = null
    activeSegmentId.value = ''
  }
  setAnalysisId(entry.id)
  rightTab.value = 'map'
  await loadExistingAnalysis()
}

async function deleteHistory(entry: HistoryEntry) {
  if (isAnalysisPending.value || deletingHistoryId.value) return
  if (!window.confirm(`永久删除“${entry.name}”的分析结果、服务器截图、练习及答题记录和本机笔记？此操作无法撤销。电脑上的原视频不会删除。`)) return
  const deletingCurrentSubtitles = subtitleCourseId.value === entry.id
  if (deletingCurrentSubtitles) clearSubtitleJob()
  ++historyGeneration;historyController?.abort();historyLoading.value=false
  deletingHistoryId.value = entry.id
  historyError.value = ''
  try {
    const response = await fetch(`${apiBase}/transcriptions/${entry.id}`, { method: 'DELETE' })
    if (response.status === 409) throw new Error('这条任务还在排队或分析中，请完成后再删除。')
    if (response.status !== 204 && response.status !== 404) throw new Error(`删除失败：HTTP ${response.status}`)
    analysisHistory.value = analysisHistory.value.filter(item => item.id !== entry.id)
    cacheHistory()
    localStorage.removeItem(`analysisMedia:${entry.id}`)
    if (localStorage.getItem('lastAnalysisId') === entry.id) localStorage.removeItem('lastAnalysisId')
    await studyNotesPanel.value?.deleteScope(entry.id)
    if (existingJobId.value === entry.id) {
      analysisState.value = ''
      analysisProgress.value = null
      clearSubtitleJob()
      invalidateAnalysisRequests()
      setAnalysisId('')
      transcript.value = []
      visualEvidence.value = []
      pageGroups.value = []
      rawMindMap.value = null
      selectedMindNode.value = null
      activeSegmentId.value = ''
      review.value = null
      failedJobId.value = ''
      unavailableFrames.value = new Set()
      status.value = '这条分析记录已删除；电脑上的原视频仍可播放或重新分析。'
    }
  } catch (cause) {
    historyError.value = cause instanceof Error ? cause.message : String(cause)
    if (deletingCurrentSubtitles && existingJobId.value === entry.id) readSubtitleJob(entry.id)
  } finally {
    deletingHistoryId.value = ''
    void refreshHistory()
  }
}

async function retryAnalysis() {
  if (!failedJobId.value || isAnalysisPending.value || generatingMindMap.value) return
  const request = analysisRequests.begin()
  isAnalysisPending.value = true
  error.value = ''
  analysisState.value = 'queued'
  analysisProgress.value = null
  status.value = '正在重新分析保留的上传文件…'
  try {
    const id = failedJobId.value
    const response = await fetch(`${apiBase}/transcriptions/${id}/retry`, { method: 'POST', signal: request.signal })
    if (!response.ok) throw new Error(response.status === 410 ? '保留的视频文件已不可用，请重新选择原视频并开始分析。' : `重试失败：HTTP ${response.status}`)
    if (!request.current()) return
    readSubtitleJob(id)
    await waitForAnalysis(id, request)
  } catch (cause) {
    if (!request.current()) return
    error.value = cause instanceof Error ? cause.message : String(cause)
    if (analysisState.value !== 'failed') analysisState.value = existingJobId.value ? 'read_failed' : 'upload_failed'
    status.value = '分析未完成'
  } finally {
    if (request.current()) isAnalysisPending.value = false
  }
}

async function generateExistingMindMap(refresh = false) {
  if (!existingJobId.value || generatingMindMap.value || isAnalysisPending.value) return
  const id = existingJobId.value
  const request = mindMapRequests.begin()
  generatingMindMap.value = true
  error.value = ''
  status.value = '正在将全部代表图和有效转写一起生成整课导图…'
  try {
    const response = await fetch(`${apiBase}/transcriptions/${id}/mind-map?refresh=${refresh}&mindMapMode=${mindMapMode}&groupedAnalysis=${groupedAnalysis}`, { method: 'POST', signal: request.signal })
    if (!response.ok) throw new Error(`导图生成失败：HTTP ${response.status}`)
    const result = await response.json() as MindMapResult
    if (!request.current() || existingJobId.value !== id) return
    rawMindMap.value = result
    selectedMindNode.value = null
    activeSegmentId.value = ''
    status.value = result.status === 'completed' ? '导图已生成并保存；点击节点可回放原片段'
      : '导图未完全生成；有依据的节点仍可回放，也可以重试'
  } catch (cause) {
    if (!request.current() || existingJobId.value !== id) return
    error.value = cause instanceof Error ? cause.message : String(cause)
    status.value = '导图生成未完成；原转写和页面分析仍可查看'
  } finally {
    if (request.current()) generatingMindMap.value = false
  }
}

function seekPlayback(startMs: number, requiresCourse: boolean, sourceId?: string): boolean {
  const player = video.value
  const fail = (message: string) => { playbackNotice.value = message; status.value = message; return false }
  if (!Number.isFinite(startMs) || startMs < 0) return fail('这个时间点无效，无法跳转。')
  if (!player || !selectedFile.value) return fail('请先选择本地视频，再跳转到这个时间点。')
  if (checkingMedia.value) return fail('正在核对视频，请稍后再跳转。')
  if (requiresCourse && !confirmedMedia.value) return fail(currentBinding.value === 'mismatch'
    ? '当前视频与历史记录不匹配，请换回对应视频后再跳转。'
    : '当前视频尚未通过课程指纹核对，请选择本课原视频。')
  if (player.readyState < 1 || player.seeking) return fail('视频正在加载或跳转，请稍后重试。')
  if (Number.isFinite(player.duration) && startMs / 1000 > player.duration) return fail('这个时间点超出当前视频长度，请核对视频与历史记录。')
  try { player.currentTime = startMs / 1000 } catch { return fail('视频暂时无法跳转，请等待加载完成后重试。') }
  // Only update the displayed clock after a real seek has been accepted.
  currentPlaybackMs.value = startMs
  if (sourceId) activeSegmentId.value = sourceId
  playbackNotice.value = ''
  const id = existingJobId.value, fingerprint = selectedFingerprint.value
  void player.play().catch(() => {
    if (video.value === player && id === existingJobId.value && fingerprint === selectedFingerprint.value) {
      status.value = '已跳转，请点击播放器继续播放'
      playbackNotice.value = '已跳转，请点击播放器继续播放'
    }
  })
  return true
}
function seekTo(startMs: number, sourceId?: string) { return seekPlayback(startMs, !!(existingJobId.value || sourceId), sourceId) }
function seekLocalNote(startMs: number) { return seekPlayback(startMs, false) }
function selectExpandedMindNode(node: MindNode) {
  expandedMap.value = false
  void selectMindMapNode(node)
}
async function selectMindMapNode(node: MindNode) {
  const id = existingJobId.value, fingerprint = selectedFingerprint.value
  selectedMindNode.value = node
  await nextTick()
  if (id !== existingJobId.value || fingerprint !== selectedFingerprint.value) return
  const evidence = node.evidenceRefs[0]
  if (!evidence) { playbackNotice.value = '这个节点没有可回放的课程依据'; return }
  if (seekTo(evidence.startMs, evidence.sourceId)) {
    scrollTranscriptTo(evidence.sourceId)
    video.value?.scrollIntoView({ behavior:'smooth', block:'center' })
  }
}

function scrollTranscriptTo(sourceId: string) {
  const target = document.getElementById(`transcript-${sourceId}`)
  if (target && transcriptList.value) {
    const listBox = transcriptList.value.getBoundingClientRect()
    const rowBox = target.getBoundingClientRect()
    transcriptList.value.scrollTop += rowBox.top - listBox.top - listBox.height / 3
  }
  const sidebarTarget = document.getElementById(`sidebar-transcript-${sourceId}`)
  if (sidebarTarget && sidebarTranscriptList.value) {
    const listBox = sidebarTranscriptList.value.getBoundingClientRect()
    const rowBox = sidebarTarget.getBoundingClientRect()
    sidebarTranscriptList.value.scrollTop += rowBox.top - listBox.top - listBox.height / 3
  }
}

function handleSidebarTabKeydown(event: KeyboardEvent) {
  if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return
  event.preventDefault()
  const current = rightTabOrder.indexOf(rightTab.value)
  const next = event.key === 'Home' ? 0 : event.key === 'End' ? rightTabOrder.length - 1
    : (current + (event.key === 'ArrowRight' ? 1 : -1) + rightTabOrder.length) % rightTabOrder.length
  rightTab.value = rightTabOrder[next]
  ;(event.currentTarget as HTMLElement).querySelectorAll<HTMLButtonElement>('[role="tab"]')[next]?.focus()
}

function formatTime(timeMs: number) { return new Date(timeMs).toISOString().slice(11, 19) }
function formatHistoryDate(value: string) {
  const date = new Date(value)
  return Number.isNaN(date.getTime()) ? '' : date.toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' })
}
function frameAt(timeMs: number) { return visualEvidence.value.find(frame => frame.frameTimeMs === timeMs) }
function markFrameUnavailable(timeMs: number) { unavailableFrames.value = new Set([...unavailableFrames.value, timeMs]) }
function syncPlayback(event: Event) {
  const timeMs = (event.target as HTMLVideoElement).currentTime * 1000
  currentPlaybackMs.value = timeMs
  if (existingJobId.value && !confirmedMedia.value) { activeSegmentId.value = ''; return }
  let low = 0
  let high = transcript.value.length - 1
  let nearest = -1
  while (low <= high) {
    const mid = (low + high) >> 1
    if (transcript.value[mid].startMs <= timeMs) { nearest = mid; low = mid + 1 }
    else high = mid - 1
  }
  const sourceId = nearest >= 0 ? transcript.value[nearest].id : ''
  if (sourceId && sourceId !== activeSegmentId.value) {
    activeSegmentId.value = sourceId
    void nextTick().then(() => scrollTranscriptTo(sourceId))
  }
}

onUnmounted(() => {
  selectionRequests.invalidate()
  analysisRequests.invalidate()
  mindMapRequests.invalidate()
  clearCompatibility()
  cueStyleElement.remove()
  clearSubtitleJob()
  video.value?.textTracks.removeEventListener('change', refreshSubtitleToggle)
  if (videoUrl.value) URL.revokeObjectURL(videoUrl.value)
  if (subtitleUrl.value) URL.revokeObjectURL(subtitleUrl.value)
})
</script>

<template>
  <RuntimeSettings v-if="runtimeSettingsOpen" @close="runtimeSettingsOpen=false" />
  <CloudSyncDialog v-if="cloudSyncOpen" :course-id="existingJobId" @close="cloudSyncOpen=false" @updated="refreshHistory" />
  <main class="study-app" :data-appearance="workspaceAppearance" :class="{ 'ambient-paused': ambientHidden || isAnalysisPending || generatingMindMap || compatibilityBusy }">
    <header class="app-header">
      <div class="brand" aria-label="Framewise"><img class="brand-symbol" src="/framewise.svg" alt="" width="35" height="35" /><span>Framewise</span></div>
      <div class="header-context"><strong>沉浸式学习台</strong><span class="header-divider" aria-hidden="true"></span><span class="header-file">{{ filename || currentHistoryName || '选择一段课程视频，开始建立知识导图' }}</span></div>
      <div class="header-actions">
        <button type="button" class="secondary" @click="runtimeSettingsOpen=true">设置</button>
        <button type="button" class="secondary" @click="cloudSyncOpen=true">云同步</button>
        <div class="appearance-switch" role="group" aria-label="界面外观">
          <button v-for="option in appearanceOptions" :key="option.value" type="button" :aria-pressed="workspaceAppearance === option.value" @click="workspaceAppearance = option.value">{{ option.label }}</button>
        </div>
        <span v-if="mindMap?.status === 'completed'" class="ready-indicator">已生成 {{ mindMap.root.children.length }} 个主题</span>
        <label class="file-picker"><StudyIcon name="upload" />选择本地视频 <input type="file" accept="video/*,audio/*" @change="chooseVideo" /></label>
        <button v-if="selectedFile && (!transcript.length || !confirmedMedia)" class="run" type="button" :disabled="isAnalysisPending || nativePreflightPending" @click="runTranscription">{{ nativePreflightPending ? '正在检查本机环境…' : isAnalysisPending ? '处理中…' : '开始分析' }}</button>
      </div>
      <AnalysisProgressBar :state="analysisState" :progress="analysisProgress" />
    </header>
    <aside class="study-sidebar" aria-label="学习工具">
      <div class="sidebar-heading"><div><span class="eyebrow">YOUR STUDY SPACE</span><h2>学习工作台</h2></div><span class="workspace-mark"><StudyIcon name="spark" />跟着课程，找到依据</span></div>
      <div class="sidebar-tabs" :style="{ '--tab-index': rightTabOrder.indexOf(rightTab) }" role="tablist" aria-label="学习工具视图" @keydown="handleSidebarTabKeydown">
        <button type="button" role="tab" aria-controls="tab-map" :aria-selected="rightTab === 'map'" :class="{ active: rightTab === 'map' }" @click="rightTab = 'map'"><StudyIcon name="map" />思维导图</button>
        <button type="button" role="tab" aria-controls="tab-practice" :aria-selected="rightTab === 'practice'" :class="{ active: rightTab === 'practice' }" @click="rightTab = 'practice'"><StudyIcon name="practice" />AI 练习</button>
        <button type="button" role="tab" aria-controls="tab-transcript" :aria-selected="rightTab === 'transcript'" :class="{ active: rightTab === 'transcript' }" @click="rightTab = 'transcript'"><StudyIcon name="transcript" />字幕原文</button>
        <button type="button" role="tab" aria-controls="tab-slides" :aria-selected="rightTab === 'slides'" :class="{ active: rightTab === 'slides' }" @click="rightTab = 'slides'"><StudyIcon name="slides" />课件画面</button>
        <button type="button" role="tab" aria-controls="tab-notes" :aria-selected="rightTab === 'notes'" :class="{ active: rightTab === 'notes' }" @click="rightTab = 'notes'"><StudyIcon name="notes" />随手笔记</button>
        <button type="button" role="tab" aria-controls="tab-history" :aria-selected="rightTab === 'history'" :class="{ active: rightTab === 'history' }" @click="rightTab = 'history'"><StudyIcon name="history" />历史记录</button>
      </div>
      <section v-show="rightTab === 'map'" id="tab-map" class="sidebar-pane" role="tabpanel" aria-label="思维导图">
        <div v-if="mindMap" class="mind-map-panel">
          <div class="mind-map-heading"><div><span class="eyebrow">KNOWLEDGE MAP</span><h2>知识导图</h2><p>图上看核心知识，点击查看公式条件与讲解细节</p></div>
            <div class="mind-map-heading-actions"><button type="button" class="expand-map-button regenerate-map-button" aria-label="重新生成导图" :disabled="generatingMindMap || isAnalysisPending || !existingJobId" title="使用已保存的课程图片和转写重新生成导图，会调用模型" @click="generateExistingMindMap(true)"><span v-if="generatingMindMap" class="activity-spinner" aria-hidden="true"></span>{{ generatingMindMap ? '正在重新生成…' : '重新生成导图' }}</button><button v-if="mindMap.root.children.length" type="button" class="expand-map-button" @click="expandedMap = true">放大查看</button><span class="mind-map-badge">{{ mindMap.root.children.length }} 个主题</span></div></div>
          <p v-if="mindMap.status === 'empty'" class="status">{{ exampleTimeline.length ? '本段课程未提取到核心知识，可通过下方例题节点回看。' : '没有可用的核心知识依据，暂时无法生成导图。' }}</p>
          <div v-else-if="mindMap.status === 'failed'" class="analysis-retry-card" role="status">
            <div><strong>{{ mindMap.root.children.length ? '导图部分生成' : '导图分析未完成' }}</strong><p>{{ generatingMindMap ? '正在使用已保存的课程资料重新生成导图，请稍候。' : mindMap.root.children.length ? '已有节点可用；其余内容未通过校验或尚未生成，可重新分析补全。' : '原转写和课件图片已保留，可以直接重新分析导图。' }}</p><details v-if="mindMapFailureReasons.length" class="map-failure-details"><summary>查看未完成原因</summary><p v-for="reason in mindMapFailureReasons" :key="reason">{{ reason }}</p></details></div>
            <button type="button" aria-label="重新分析导图" :disabled="generatingMindMap || isAnalysisPending || !existingJobId" @click="generateExistingMindMap(false)"><span v-if="generatingMindMap" class="activity-spinner" aria-hidden="true"></span>{{ generatingMindMap ? '重新分析中…' : '重新分析' }}</button>
          </div>
          <MindMapCanvas v-if="mindMap.root.children.length" :root="mindMap.root" @select="selectMindMapNode" />
          <div v-if="showMindMapEvidence && selectedMindNode && (selectedMindNode.evidenceRefs.length || selectedMindNode.details?.length)" class="mind-source">
            <strong>{{ selectedMindNode.title }} · 课程依据</strong>
            <MindMapEvidenceDetails v-if="selectedMindNode.details?.length" :nodes="selectedMindNode.details" :api-base="apiBase" :course-id="existingJobId" :frame-times="visualEvidence.map(frame => frame.frameTimeMs)" @seek="seekTo" />
            <button v-for="source in selectedMindNode.evidenceRefs" :key="source.sourceId" type="button" class="mind-source-link" @click="seekTo(source.startMs, source.sourceId)">
              <span class="time">{{ formatTime(source.startMs) }}</span> {{ source.quote }}
            </button>
            <img v-for="source in selectedMindNode.evidenceRefs.filter(ref => ref.sourceType === 'image' && frameAt(ref.startMs))" :key="source.sourceId" loading="lazy" :src="`${apiBase}/transcriptions/${existingJobId}/frames/${source.startMs}`" :alt="`${formatTime(source.startMs)} 的课件截图`" class="mind-evidence-image" />
          </div>
          <section v-if="exampleTimeline.length" class="example-timeline" aria-label="例题时间节点">
            <div class="example-timeline-heading"><h3>例题时间节点</h3><span>{{ exampleTimeline.length }} 道例题</span></div>
            <p>每道例题一个入口，点击从题目开始处回看完整讲解。</p>
            <button v-for="example in exampleTimeline" :key="example.id" type="button" @click="seekTo(example.evidenceRefs[0]?.startMs ?? example.startMs, example.evidenceRefs[0]?.sourceId)"><span class="time">{{ formatTime(example.startMs) }}</span><span>{{ example.title }}</span><StudyIcon name="play" /></button>
          </section>
        </div>
        <div v-else class="sidebar-empty">
          <div v-if="failedJobId" class="analysis-retry-card" role="status"><div><strong>课程分析未完成</strong><p>{{ isAnalysisPending ? '正在重新分析，请稍候。' : '可以使用保留的任务文件重新分析，无需再次上传。' }}</p></div><button type="button" aria-label="重新分析课程" :disabled="isAnalysisPending || generatingMindMap" @click="retryAnalysis">{{ isAnalysisPending ? '重新分析中…' : '重新分析' }}</button></div>
          <div class="map-preview" aria-hidden="true"><span class="preview-root"><StudyIcon name="play" />课程</span><i></i><div><span><StudyIcon name="map" />知识脉络</span><span><StudyIcon name="transcript" />原文依据</span><span><StudyIcon name="notes" />学习笔记</span></div></div>
          <span class="eyebrow">KNOWLEDGE MAP</span><h3>让知识点回到原视频</h3>
          <p>分析完成后，这里会生成可展开的课程导图。点击任一节点，就能回看老师讲解它的片段和原句。</p>
          <div class="empty-steps"><span><b>01</b> 选择本地课程视频</span><span><b>02</b> 运行语音与画面分析</span><span><b>03</b> 点击导图回看依据</span></div>
          <p class="empty-hint" :class="{ 'is-processing': isAnalysisPending }"><span v-if="isAnalysisPending" class="activity-spinner" aria-hidden="true"></span>{{ isAnalysisPending ? '正在分析课程，完成后导图将在这里显示。你可以继续观看本地视频。' : selectedFile ? '视频已选好，点击顶部“开始分析”；已有任务可在下方按编号读取结果。' : '先点击右上角“选择本地视频”；已有任务可在下方按编号读取结果。' }}</p>
        </div>
      </section>
      <section v-show="rightTab === 'practice'" id="tab-practice" class="sidebar-pane" role="tabpanel" aria-label="AI 练习"><AiPractice :course-id="(transcript.length || pageGroups.length || mindMap) && existingJobId ? existingJobId : undefined" :has-media="!!selectedFile || checkingMedia" :playback-ready="confirmedMedia" :mind-map="rawMindMap" :selected-node-id="selectedMindNode?.id" :ready="rawMindMap?.status === 'completed'" @seek="seekTo" /></section>
      <section v-show="rightTab === 'transcript'" id="tab-transcript" class="sidebar-pane" role="tabpanel" aria-label="字幕原文">
        <div class="sidebar-pane-heading"><div><span class="eyebrow">TRANSCRIPT</span><h3>字幕原文</h3></div><span>{{ transcript.length }} 段</span></div>
        <template v-if="transcript.length">
          <label class="sidebar-search-label" for="transcript-search">搜索课程内容</label>
          <input id="transcript-search" v-model="transcriptQuery" class="sidebar-search" type="search" placeholder="输入关键词查找讲解…" />
          <p v-if="subtitleChanges.length" class="subtitle-review-hint">原文保留如下；展开标记可查看 AI {{ subtitleIsTranslation ? '翻译' : '校正' }}和依据。</p>
          <div ref="sidebarTranscriptList" class="sidebar-transcript-list">
            <div v-for="segment in filteredTranscript" :key="segment.id" class="transcript-entry">
              <button :id="`sidebar-transcript-${segment.id}`" type="button" class="sidebar-row" :class="{ 'active-segment': segment.id === activeSegmentId }" @click="seekTo(segment.startMs, segment.id)">
                <span class="time">{{ formatTime(segment.startMs) }}</span><span>{{ segment.text }}</span>
              </button>
              <details v-if="subtitleChangeById.has(segment.id)" class="subtitle-change">
                <summary>查看 AI {{ subtitleIsTranslation ? '翻译' : '校正' }}</summary>
                <p><strong>原文</strong>{{ subtitleChangeById.get(segment.id)?.originalText }}</p>
                <p><strong>AI {{ subtitleIsTranslation ? '翻译' : '校正' }}</strong>{{ subtitleChangeById.get(segment.id)?.text }}</p>
                <p>{{ subtitleChangeById.get(segment.id)?.reason }}</p>
                <div v-if="subtitleChangeById.get(segment.id)?.evidence?.length" class="subtitle-change-evidence">
                  <span>相关课件文字</span>
                  <button v-for="(evidence, index) in subtitleChangeById.get(segment.id)?.evidence" :key="index" type="button" @click="seekTo(evidence.sourceFrameTimeMs)">{{ formatTime(evidence.sourceFrameTimeMs) }} · {{ evidence.text }}</button>
                </div>
              </details>
            </div>
            <p v-if="!filteredTranscript.length" class="sidebar-message">没有找到包含“{{ transcriptQuery }}”的讲解。</p>
          </div>
        </template>
        <div v-else class="sidebar-empty compact"><h3>字幕还没生成</h3><p>分析课程后，可在这里搜索老师说过的话，点击任一行直接回放。</p></div>
      </section>
      <section v-show="rightTab === 'slides'" id="tab-slides" class="sidebar-pane" role="tabpanel" aria-label="课件画面">
        <div class="sidebar-pane-heading"><div><span class="eyebrow">VISUAL EVIDENCE</span><h3>课件画面</h3></div><span>{{ pageGroups.length ? `${pageGroups.length} 页` : `${visualEvidence.length} 张候选图` }}</span></div>
        <PageGallery v-if="pageGroups.length" :pages="pageGroups" :course-id="existingJobId" :time-ms="confirmedMedia ? currentPlaybackMs : 0" @seek="seekTo" />
        <template v-else-if="visualEvidence.length">
          <p class="sidebar-message">这是旧任务的候选截图记录；原图可能已被清理，文字和时间仍可查看。</p>
          <div class="sidebar-slide-list"><button v-for="frame in visualEvidence" :key="frame.frameTimeMs" type="button" class="sidebar-slide-row" @click="seekTo(frame.frameTimeMs)"><span class="time">{{ formatTime(frame.frameTimeMs) }}</span><span>{{ frame.imageAnalysis?.title || frame.ocrBlocks.slice(0, 2).map(block => block.text).join(' · ') || '候选画面' }}</span></button></div>
        </template>
        <div v-else class="sidebar-empty compact"><h3>课件证据还没生成</h3><p>分析时会抽取关键画面、识别课件文字，并关联到视频时间。</p></div>
      </section>
      <section v-show="rightTab === 'notes'" id="tab-notes" class="sidebar-pane" role="tabpanel" aria-label="随手笔记">
        <StudyNotes ref="studyNotesPanel" :scopes="noteScopes" :video="video" :time-ms="currentPlaybackMs" @seek="seekLocalNote" />
      </section>
      <section v-show="rightTab === 'history'" id="tab-history" class="sidebar-pane" role="tabpanel" aria-label="历史记录">
        <div class="sidebar-pane-heading"><div><span class="eyebrow">MY LIBRARY</span><h3>分析历史</h3></div><span>{{ analysisHistory.length }} 条记录</span></div>
        <p class="sidebar-message">保存的是任务编号和课程记录，不保存视频。点击记录可读取字幕、导图和课件文字；回放时请重新选择本地原视频。</p>
        <button type="button" class="text-link" :disabled="historyLoading || !!deletingHistoryId" @click="refreshHistory">{{ historyLoading ? '同步中…' : '刷新历史' }}</button>
        <p v-if="historyError" class="history-error" role="alert">{{ historyError }}</p>
        <div v-if="analysisHistory.length" class="history-list">
          <article v-for="entry in analysisHistory" :key="entry.id" class="history-item">
            <button type="button" class="history-open" :disabled="(isAnalysisPending && !analysisReadOnly) || !!deletingHistoryId" @click="openHistory(entry)">
              <span class="history-item-top"><strong>{{ entry.name }}</strong><span>{{ historyStatusLabel(entry.status) }}</span></span>
              <small>创建于 {{ formatHistoryDate(entry.addedAt) }} · {{ entry.id }}</small>
            </button>
            <button type="button" class="history-delete" :aria-label="`永久删除 ${entry.name} 的分析记录`" :disabled="isAnalysisPending || !!deletingHistoryId" @click="deleteHistory(entry)">{{ deletingHistoryId === entry.id ? '删除中…' : '删除' }}</button>
          </article>
        </div>
        <div v-else class="sidebar-empty compact"><h3>{{ historyLoading ? '正在读取历史记录' : historySynced ? '还没有历史记录' : '尚未读取到历史记录' }}</h3><p>分析记录由服务器统一保存。</p></div>
        <p class="sidebar-message">历史列表从当前服务同步，清除浏览器缓存后仍可恢复。删除记录会同时清理服务器分析结果、截图及关联练习。</p>
      </section>
    </aside>
    <WorkspaceDivider />
    <section class="workspace">
      <div class="panel player-panel">
        <div class="section-title"><h2>课程视频</h2><div class="player-tools"><button type="button" class="subtitle-toggle workspace-entry" @click="openVideoWorkspace"><StudyIcon name="slides" />视频工作台<span v-if="ignoredRegion||analysisRegion||personSelectionMode==='adjacent'" class="workspace-entry-dot" aria-label="已保存视频处理设置"></span></button><button v-if="selectedFile" type="button" class="subtitle-toggle" :disabled="compatibilityBusy" title="使用后台显卡生成 H.264 播放副本，需要上传原视频，不重新分析课程" @click="generateCompatibility">{{ compatibilityBusy ? '转换中…' : compatibilityActive ? '返回原视频' : compatibilityId ? '使用兼容副本' : '显卡兼容播放' }}</button><button v-if="compatibilityBusy" type="button" class="subtitle-toggle" @click="cancelCompatibility">取消转码</button><button v-if="transcript.length && videoUrl && confirmedMedia" type="button" class="subtitle-toggle" :aria-pressed="subtitleEnabled" @click="subtitleEnabled = !subtitleEnabled"><StudyIcon name="transcript" />字幕{{ subtitleEnabled ? '已开启' : '已关闭' }}</button><span>{{ compatibilityActive ? '兼容播放' : '本地播放' }} · {{ videoUrl ? formatTime(currentPlaybackMs) : '尚未选择文件' }}</span></div></div>
        <p v-if="compatibilityMessage" class="empty-hint" role="status" aria-live="polite">{{ compatibilityMessage }}</p>
        <div v-if="associationVisible" class="media-association" :class="currentBinding" role="status">
          <strong>{{ checkingMedia ? '正在核对视频…' : confirmedMedia ? '已自动关联本课' : currentBinding === 'mismatch' ? '视频不匹配 · 未关联' : '无法自动关联' }}</strong>
          <template v-if="!confirmedMedia && !checkingMedia"><p>当前视频：{{ filename }}<br />历史记录：{{ currentHistoryName || existingJobId }}</p>
          <p>{{ currentBinding === 'mismatch' ? '当前文件与这条记录保存的视频不同，课程时间跳转和字幕已停用。请换回对应视频或选择正确的历史记录。' : '这条记录尚无可用的服务端视频指纹，请查看下方提示；核对完成前课程时间跳转暂不可用。' }}</p>
          <button type="button" class="text-link" @click="rightTab='history'">选择其他历史记录</button></template>
        </div>
        <p v-if="playbackNotice" class="empty-hint playback-notice" role="alert">{{ playbackNotice }}</p>
        <div v-if="transcript.length" class="subtitle-controls">
          <SubtitleSettings v-model="subtitleAppearance" />
          <div class="subtitle-mode" role="group" aria-label="字幕版本">
            <button type="button" :aria-pressed="selectedSubtitles.mode === 'original'" @click="subtitleMode = 'original'">原文字幕</button>
            <button type="button" :aria-pressed="selectedSubtitles.mode === 'ai'" :disabled="!aiSubtitlesAvailable" @click="subtitleMode = 'ai'">AI {{ subtitleIsTranslation ? '翻译' : '校正' }}字幕</button>
          </div>
          <label v-if="subtitleCourseId" class="subtitle-target" for="player-subtitle-language">AI 字幕语言
            <select id="player-subtitle-language" v-model="subtitleTargetLanguage" :disabled="requestingSubtitles || isAnalysisPending"><option value="source">保持原语言（仅校正）</option><option value="zh">中文</option><option value="en">English</option></select>
          </label>
          <button v-if="subtitleCourseId" type="button" class="subtitle-generate" :disabled="!canGenerateSubtitles" @click="generateSubtitles">{{ requestingSubtitles || ['awaiting_source', 'queued', 'processing'].includes(subtitleJob?.status ?? '') ? '生成中…' : subtitleNeedsUpdate ? '更新 AI 字幕' : ['completed', 'partial'].includes(subtitleJob?.status ?? '') ? '重新生成 AI 字幕' : subtitleJob?.status === 'failed' ? '重试生成 AI 字幕' : '生成 AI 字幕' }}</button>
        </div>
        <p v-if="subtitleStatusMessage" class="subtitle-status" :class="{ 'subtitle-status-warning': subtitleRequestError || ['failed', 'partial', 'unsupported'].includes(subtitleJob?.status ?? '') }" role="status" aria-atomic="true">{{ subtitleStatusMessage }}</p>
        <ChapterPlayer v-if="videoUrl" :src="videoUrl" :chapters="confirmedMedia ? videoChapters : []" :chapter-status="confirmedMedia ? chapterStatus : 'not_requested'" @ready="video = $event" @timeupdate="syncPlayback"><track v-if="subtitleUrl && confirmedMedia" :key="subtitleUrl" :src="subtitleUrl" kind="subtitles" :label="selectedSubtitles.mode === 'ai' ? 'AI 字幕' : '原文字幕'" :srclang="selectedSubtitles.language" default @load="syncSubtitleVisibility" /></ChapterPlayer>
        <div v-else class="empty-player">
          <div class="player-orbit orbit-one" aria-hidden="true"></div><div class="player-orbit orbit-two" aria-hidden="true"></div>
          <div class="player-welcome"><span class="player-play-mark"><StudyIcon name="play" /></span><span class="player-kicker">WATCH. UNDERSTAND. CONNECT.</span><h3>从一节课，连接每个知识点</h3><p>选择本地视频或录音，开启你的学习工作台</p><label class="player-file-picker"><StudyIcon name="upload" />选择课程文件<input type="file" accept="video/*,audio/*" @change="chooseVideo" /></label></div>
          <span class="player-local-badge"><StudyIcon name="lock" />本地播放 · 原文件保留在你的电脑</span>
        </div>
        <p class="player-caption"><StudyIcon name="lock" />{{ filename || '本地回放 · 分析后点击知识节点，回到老师的讲解现场' }}</p>
      </div>
      <details class="panel video-overview">
        <summary><span class="video-overview-title"><StudyIcon name="spark" />AI 解读</span><span class="video-overview-hint">课程介绍 · 学习笔记</span><span class="video-overview-chevron" aria-hidden="true">⌄</span></summary>
        <AiOverview :course-id="existingJobId" :ready="rawMindMap?.status === 'completed'" @state="overviewState=$event" @seek="seekTo" />
      </details>
      <OverviewChat :course-id="existingJobId" :overview-ready="overviewState.status==='completed'" :overview-revision="overviewState.revision" :playback-ready="confirmedMedia" @seek="seekTo" />
      <div class="panel results-panel">
        <div class="section-title"><h2>课程依据</h2><span>{{ transcript.length }} 段字幕 · {{ pageGroups.length ? `${pageGroups.length} 页课件` : `${visualEvidence.length} 张候选画面` }}</span></div>
        <p class="status" :class="{ 'is-processing': isAnalysisPending }" role="status"><span v-if="isAnalysisPending" class="activity-spinner" aria-hidden="true"></span>{{ status }}</p><p v-if="error" class="error">{{ error }}</p>
        <button v-if="isAnalysisPending && existingJobId && ['queued','processing'].includes(analysisState)" type="button" class="text-link" @click="cancelAnalysis">取消分析</button>
        <button v-if="analysisState==='read_failed' && existingJobId && !isAnalysisPending" type="button" class="text-link" @click="loadExistingAnalysis">重试读取（不会重新分析）</button>
        <details class="analysis-settings" :open="!transcript.length">
          <summary>分析与任务设置</summary>
          <div class="analysis-settings-content">
        <label class="mode-picker">画面分析方式 <select v-model="visualAnalysisMode" disabled><option value="both">语音文字＋每页代表图</option><option value="ocr_only">语音文字＋OCR 文字</option></select></label>
        <div class="advanced-options">
          <button type="button" class="advanced-toggle" :aria-expanded="advancedOpen" aria-controls="advanced-settings" @click="advancedOpen = !advancedOpen">{{ advancedOpen ? '收起高级选项' : '高级选项' }}</button>
          <div v-if="advancedOpen" id="advanced-settings" class="advanced-fields">
          <div class="advanced-row map-mode-row">
            <span id="mind-map-mode-label">导图生成方式</span>
            <span class="map-mode-value" aria-labelledby="mind-map-mode-label">整课图文直生成</span>
          </div>
          <p class="advanced-help">保留覆盖检查与缺失截图补采，等全部代表图和语音转写就绪后，将代表图与有效转写一起交给思维导图模型，跳过逐组内容解读。图片较多时，请求可能达到模型上限；不会自动删图或改成分批。</p>
          <p class="advanced-help">新分析和手动生成导图均使用整课图文直生成；重试整次分析沿用原任务设置。课件图片会发送到已配置的模型服务。</p>
          <div class="advanced-row">
            <span id="coarse-sample-label">粗选采样间隔</span>
            <div class="sampling-options" role="group" aria-labelledby="coarse-sample-label">
              <button v-for="seconds in [2, 3, 4]" :key="seconds" type="button" :aria-pressed="coarseSampleSeconds === seconds" :disabled="isAnalysisPending" @click="coarseSampleSeconds = seconds">{{ seconds }} 秒{{ seconds === 2 ? '（默认）' : '' }}</button>
            </div>
          </div>
          <p class="advanced-help">间隔越长，扫描预览帧越少，但可能漏掉短暂出现的公式、表格或板书。仅影响新分析；重试沿用原任务设置。</p>
          <div class="advanced-row">
            <label for="coarse-change-percent">粗选画面变化阈值</label>
            <span class="help-tooltip" tabindex="0" aria-label="粗选画面变化阈值说明">?
              <span role="tooltip">按所选采样间隔比较画面。相邻画面变化区域超过所选比例时，保留候选截图；渐进书写另有保留规则。默认 3%。数值越低通常候选图越多，越不容易漏掉小变化；越高则候选图越少，但可能漏掉新画面。此值只影响第一轮粗选。</span>
            </span>
            <select id="coarse-change-percent" v-model="coarseChangePercent">
              <option value="0.5">0.5%</option><option value="1">1%</option>
              <option value="2">2%</option><option value="3">3%（默认）</option>
              <option value="4">4%</option><option value="5">5%</option>
            </select>
          </div>
          </div>
        </div>
        <div class="restore"><label for="analysis-id">已有分析编号</label><div class="actions"><input id="analysis-id" v-model="existingJobId" placeholder="粘贴任务编号" /><button class="secondary" :disabled="!existingJobId.trim() || isAnalysisPending" @click="loadExistingAnalysis">读取结果</button></div><small>已分析过的视频可直接读取结果；播放原片段时仍需选择本地视频。</small></div>
        <button v-if="failedJobId" class="secondary" :disabled="isAnalysisPending || generatingMindMap" @click="retryAnalysis">{{ isAnalysisPending ? '重新分析中…' : '重新分析' }}</button>
        <button v-if="transcript.length && existingJobId && (!mindMap || mindMap.status === 'failed')"
          class="secondary" :disabled="generatingMindMap" @click="generateExistingMindMap(false)">
          {{ generatingMindMap ? '正在生成导图…' : mindMap ? '重试生成导图' : '从已有转写生成导图' }}
        </button>
        <button v-if="mindMap?.status === 'completed' && existingJobId" class="secondary"
          :disabled="generatingMindMap" @click="generateExistingMindMap(true)">
          {{ generatingMindMap ? '正在重新生成…' : '重新生成导图' }}
        </button>
          </div>
        </details>
        <details v-if="transcript.length || pageGroups.length || visualEvidence.length" class="full-analysis">
          <summary>查看完整分析记录 <span>OCR 原文、页面理解与候选截图</span></summary>
        <div class="evidence-workbench">
        <div v-if="transcript.length" class="points transcript-pane"><h3>同步字幕 <small>点击原文回放</small></h3><div ref="transcriptList" class="transcript-list">
          <button v-for="segment in transcript" :id="`transcript-${segment.id}`" :key="segment.id" class="point"
            :class="{ 'active-segment': segment.id === activeSegmentId }" @click="seekTo(segment.startMs, segment.id)">
            <span class="time">{{ new Date(segment.startMs).toISOString().slice(11, 19) }}</span>
            <span>{{ segment.text }}</span>
          </button>
        </div></div>
        <div v-if="pageGroups.length" class="points slides-pane"><h3>对应课件 <small>{{ pageGroups.length }} 页</small></h3>
          <div v-if="activeSlide" class="current-slide"><img v-if="activeSlide.representativeFrameTimesMs.length && !unavailableFrames.has(activeSlide.representativeFrameTimesMs[0])" loading="lazy" :src="`${apiBase}/transcriptions/${existingJobId}/frames/${activeSlide.representativeFrameTimesMs[0]}`" :alt="`第 ${activeSlide.pageIndex} 页课件画面`" @error="markFrameUnavailable(activeSlide.representativeFrameTimesMs[0])" /><p>第 {{ activeSlide.pageIndex }} 页 · {{ activeSlide.imageAnalysis?.title || activeSlide.textAnalysis?.title || '课程画面' }}</p></div>
          <details v-for="page in pageGroups" :key="page.pageIndex" class="visual-frame">
            <summary><span class="time">{{ formatTime(page.firstFrameTimeMs) }}</span>第 {{ page.pageIndex }} 页 · {{ page.imageAnalysis?.title || page.textAnalysis?.title || page.ocrLines.slice(0, 2).map(line => line.text).join(' · ') || '画面内容' }}<span v-if="page.imageAnalysis?.status === 'failed' || page.textAnalysis?.status === 'failed'"> · 本页理解失败</span><span v-if="page.imageAnalysis?.status === 'inferred' || page.textAnalysis?.status === 'inferred'"> · 含推导内容</span><span v-if="page.imageAnalysis?.status === 'unverified' || page.textAnalysis?.status === 'unverified'"> · 部分内容未核实 ？</span></summary>
            <div class="actions page-actions"><button class="secondary" @click="seekTo(page.firstFrameTimeMs)">从本页开始播放</button><button class="secondary" @click="seekTo(page.representativeFrameTimesMs[0] ?? page.firstFrameTimeMs)">跳到代表画面</button></div>
            <img v-for="timeMs in page.representativeFrameTimesMs" :key="timeMs" loading="lazy" :src="`${apiBase}/transcriptions/${existingJobId}/frames/${timeMs}`" :alt="`${formatTime(timeMs)} 的课程画面`" />
            <div class="evidence-columns"><section><h4>本页 OCR 文字</h4><p v-if="!page.ocrLines.length">未识别出文字</p><p v-for="line in page.ocrLines" :key="`${line.sourceFrameTimeMs}-${line.sourceBlockIndex}`"><button class="text-link" @click="seekTo(line.sourceFrameTimeMs)">{{ formatTime(line.sourceFrameTimeMs) }}</button> {{ line.text }}</p></section>
              <section v-if="page.imageAnalysis"><h4>语音＋图片理解</h4><p class="analysis-content">{{ page.imageAnalysis.content }}</p><p v-if="page.imageAnalysis.visualElements.length">图表/图形：{{ page.imageAnalysis.visualElements.join('；') }}</p><p v-if="page.imageAnalysis.uncertainties.length">待核实：{{ page.imageAnalysis.uncertainties.join('；') }}</p></section>
              <section v-else-if="page.textAnalysis"><h4>语音＋OCR 文字理解</h4><p class="analysis-content">{{ page.textAnalysis.content }}</p><p v-if="page.textAnalysis.visualElements.length">图表/图形：{{ page.textAnalysis.visualElements.join('；') }}</p><p v-if="page.textAnalysis.uncertainties.length">待核实：{{ page.textAnalysis.uncertainties.join('；') }}</p></section>
              <section v-else><h4>本页理解</h4><p>这份结果尚无页面理解内容。</p></section>
            </div>
            <details class="source-frames"><summary>查看本页 {{ page.memberFrameTimesMs.length }} 张原始候选截图</summary><div v-for="timeMs in page.memberFrameTimesMs" :key="timeMs"><button class="text-link" @click="seekTo(timeMs)">{{ formatTime(timeMs) }}</button> {{ frameAt(timeMs)?.ocrBlocks.map(block => block.text).join(' · ') || '无 OCR 文字' }}<img loading="lazy" :src="`${apiBase}/transcriptions/${existingJobId}/frames/${timeMs}`" :alt="`${formatTime(timeMs)} 的原始候选截图`" /></div></details>
          </details>
          <p v-if="review?.resampledTimesMs?.length" class="status">Agent 补采了 {{ review.resampledTimesMs.length }} 张画面。</p>
        </div>
        <div v-else-if="visualEvidence.length" class="points slides-pane"><h3>PPT 候选画面（旧任务）</h3>
          <div v-if="activeLegacyFrame && !unavailableFrames.has(activeLegacyFrame.frameTimeMs)" class="current-slide"><img loading="lazy" :src="`${apiBase}/transcriptions/${existingJobId}/frames/${activeLegacyFrame.frameTimeMs}`" :alt="`${formatTime(activeLegacyFrame.frameTimeMs)} 的课程画面`" @error="markFrameUnavailable(activeLegacyFrame.frameTimeMs)" /><p>{{ formatTime(activeLegacyFrame.frameTimeMs) }} · {{ activeLegacyFrame.imageAnalysis?.title || '对应课程画面' }}</p></div>
          <details v-for="frame in visualEvidence" :key="frame.frameTimeMs" class="visual-frame">
            <summary><span class="time">{{ new Date(frame.frameTimeMs).toISOString().slice(11, 19) }}</span> {{ frame.imageAnalysis?.title || frame.ocrBlocks.slice(0, 2).map(block => block.text).join(' · ') || '候选画面' }}<span v-if="frame.imageAnalysis?.status === 'failed'"> · 图片理解失败</span></summary>
            <button class="secondary" @click="seekTo(frame.frameTimeMs)">跳到这段视频</button>
            <img v-if="frame.imageAnalysis" loading="lazy" :src="`${apiBase}/transcriptions/${existingJobId}/frames/${frame.frameTimeMs}`" :alt="`${frame.frameTimeMs} 毫秒时的课程画面`" />
            <div class="evidence-columns">
              <section><h4>OCR 原文</h4><p>{{ frame.ocrBlocks.map(block => block.text).join(' · ') || '未识别出文字' }}</p></section>
              <section v-if="frame.imageAnalysis"><h4>图片理解</h4><p>{{ frame.imageAnalysis.content }}</p><p v-if="frame.imageAnalysis.visualElements.length">图表/图形：{{ frame.imageAnalysis.visualElements.join('；') }}</p><p v-if="frame.imageAnalysis.uncertainties.length">未看清：{{ frame.imageAnalysis.uncertainties.join('；') }}</p></section>
              <section v-else><h4>图片理解</h4><p>旧任务未进行图片分析</p></section>
            </div>
          </details>
          <p v-if="review?.resampledTimesMs?.length" class="status">Agent 补采了 {{ review.resampledTimesMs.length }} 张画面。</p>
        </div>
        </div>
        </details>
      </div>
    </section>
    <MindMapDialog v-if="expandedMap && mindMap?.root.children.length" :root="mindMap.root" @close="expandedMap = false" @select="selectExpandedMindNode" />
    <VideoWorkspace v-if="workspaceOpen" :src="videoUrl" :filename="filename" :model-value="ignoredRegion" :analysis-region="analysisRegion" :person-selection-mode="personSelectionMode" :analysis-pending="isAnalysisPending" @update:person-selection-mode="updatePersonSelection" @update:analysis-region="saveAnalysisRegion" :time-ms="currentPlaybackMs" :checking="checkingMedia" @close="workspaceOpen=false" @select-file="chooseVideo" @update:model-value="saveIgnoredRegion" />
  </main>
</template>
